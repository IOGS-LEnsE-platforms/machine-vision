# -*- coding: utf-8 -*-
"""
Created on Wed Mar 29 09:53:02 2023

@author: jade.barret alexis.corbillet maurice.mannoni
"""

import sys
import time

from PyQt5.QtGui import *
from PyQt5.QtWidgets import *
from PyQt5.QtCore import *
from PyQt5 import uic

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.metrics import confusion_matrix
from sklearn.metrics import ConfusionMatrixDisplay

from pyueye import ueye
import cv2
from PIL import Image
from scipy import ndimage
import webcolors

from threading import Timer, Thread, Event
from datetime import datetime

from serial import Serial
import serial.tools.list_ports





class PerpetualTimer():

    def __init__(self, t, hFunction):
        self.t = t
        self.hFunction = hFunction
        self.thread = Timer(self.t, self.handle_function)

    def handle_function(self):
        self.hFunction()
        self.thread = Timer(self.t, self.handle_function)
        self.thread.start()

    def start(self):
        self.thread.start()




class IAFormes():

    def __init__(self,Test=False):
        self.__test=Test
        if Test:
            #Lecture de la base de test
            dfAt = pd.read_csv(r'/Users/alexis/Desktop/Supop/Projet IETI/BaseATEST.csv')
            dfCt = pd.read_csv(r'/Users/alexis/Desktop/Supop/Projet IETI/BaseCercleTEST.csv')
            dfTt = pd.read_csv(r'/Users/alexis/Desktop/Supop/Projet IETI/BaseTriTEST.csv')
            dfPt = pd.read_csv(r'/Users/alexis/Desktop/Supop/Projet IETI/BasePentTEST.csv')
            dfEt = pd.read_csv(r'/Users/alexis/Desktop/Supop/Projet IETI/BaseEtTEST.csv')

            xt1=[dfAt[str(i)].values for i in range(500)]
            xt2=[dfCt[str(i)].values for i in range(500)]
            xt3=[dfTt[str(i)].values for i in range(500)]
            xt4=[dfPt[str(i)].values for i in range(500)]
            xt5=[dfEt[str(i)].values for i in range(500)]

            #print("Bases de test importées")

            xt=xt1+xt2+xt3+xt4+xt5+[[0]*3264]*500
            xt=np.array(xt)

            yt=[0]*(500)+[1]*(500)+[2]*(500)+[3]*(500)+[4]*(500)+[-1]*500#attention a verifier cette ligne
            #Carre : 0 Cercle : 1 Triangle : 2 Pentagone : 3 Etoile : 4
            yt=np.array(yt)
            x_test = xt
            y_test = yt
            self.xt=xt
            self.yt=yt

        #Initialisation du réseau
        x=np.zeros((6,3264))
        y=yt=[0]+[1]+[2]+[3]+[4]+[-1]
        y=np.array(y)

        self.__mlp2=MLPClassifier(hidden_layer_sizes=([256,128]), activation='logistic', alpha=1e-4, solver='sgd', tol=5e-3, random_state=0, verbose=False,max_iter=1,warm_start=False,learning_rate_init=0.005)
        self.__mlp2.fit(x,y)

        A=np.load("Poids-1.npy",allow_pickle=True)
        #print(len(A))
        A=[A[0],A[1],A[2]]
        B=np.load("Biais-1.npy",allow_pickle=True)
        B=[B[0],B[1],B[2]]
        self.__mlp2.coefs_=A
        self.__mlp2.intercepts_=B

        #print(self.__mlp2.classes_)

        if Test:
            print("Test set score: %f" % self.__mlp2.score(x_test, y_test))

    def montreimage(self,k,set):
        X=np.reshape(set[k],(51,64))
        plt.imshow(X,cmap='Greys_r')
        plt.show()

    def matconf(self):
        if self.__test:
            # affichage de la matrice de confusion
            y_pred = self.__mlp2.predict(self.xt)
            cm = confusion_matrix(self.yt, y_pred)
            cm_display = ConfusionMatrixDisplay(cm).plot()
            plt.show()
        else:
            print("Pas de base de test")

    def Proba(self, xtest):
        return self.__mlp2.predict_proba(xtest)
    def Proba2(self, xtest):
        return self.__mlp2.predict(xtest)



class Couleurim():

    def __init__(self,Foldername='/Users/alexis/Desktop/Supop/Projet IETI/images/o1.bmp', livemode=False, Frame=None):

        if livemode==False:
            img = Image.open(Foldername)
        else:
            img=Frame

        r, g, b = img.split()
        self.r=np.array(r)
        self.g=np.array(g)
        self.b=np.array(b)
        (n,p)=self.r.shape
        r=self.r.max()
        self.argr=np.unravel_index(self.r.argmax(), (n,p))
        g=self.g.max()
        self.argg=np.unravel_index(self.g.argmax(), (n,p))
        b=self.b.max()
        self.argb=np.unravel_index(self.b.argmax(), (n,p))
        self.nc=[r,g,b]
        ma =self.nc.index(max(self.nc))
        if ma==0:
            self.argb=self.argr
            self.argg=self.argr
        if ma==1:
            self.argb=self.argg
            self.argr=self.argg
        if ma==2:
            self.argr=self.argb
            self.argg=self.argb
        self.nc=[self.r[self.argr],self.g[self.argg],self.b[self.argb]]
        #print([self.argr,self.argg,self.argb])

    def affichage(self):

        r=self.r
        b=self.b
        g=self.g
        nc=self.nc
        (n,p)=r.shape
        #print(r.shape)
        f=5
        for k in range(p):
            for i in range(-f,f):
                if (self.argr[0]+i)>0 and (self.argr[0]+i)<n:
                    r[self.argr[0]+i,k]=255
                if (self.argg[0]+i)>0 and (self.argg[0]+i)<n:
                    g[self.argg[0]+i,k]=255
                if (self.argb[0]+i)>0 and (self.argb[0]+i)<n:
                    b[self.argb[0]+i,k]=255
        for k in range(n):
            for i in range(-f,f):
                if (self.argr[1]+i)>0 and (self.argr[1]+i)<p:
                    r[k,self.argr[1]+i]=255
                if (self.argg[1]+i)>0 and (self.argg[1]+i)<p:
                    g[k,self.argg[1]+i]=255
                if (self.argb[1]+i)>0 and (self.argb[1]+i)<p:
                    b[k,self.argb[1]+i]=255

        fig, ax = plt.subplots(2,2)
        ax[0,0].imshow(r,cmap='Reds_r')
        ax[0,0].set_title("Nuances de rouge")
        ax[0,0].axis('off')
        ax[1,0].imshow(g,cmap='Greens_r')
        ax[1,0].set_title("Nuances de vert")
        ax[1,0].axis('off')
        ax[0,1].imshow(b,cmap='Blues_r')
        ax[0,1].set_title("Nuances de bleu")
        ax[0,1].axis('off')
        ax[1,1].imshow([[nc]])
        ax[1,1].set_title(self.couleur_proche(nc))
        #ax[1,1].axis('off')
        plt.show()

    def couleur_proche(self, requested_colour=None):

        if requested_colour==None:
            requested_colour=self.nc
        min_colours = {}
        for key, name in webcolors.CSS3_HEX_TO_NAMES.items():
            r_c, g_c, b_c = webcolors.hex_to_rgb(key)
            rd = (r_c - requested_colour[0]) ** 2
            gd = (g_c - requested_colour[1]) ** 2
            bd = (b_c - requested_colour[2]) ** 2
            min_colours[(rd + gd + bd)] = name
        return min_colours[min(min_colours.keys())]




class IAcouleurs():

    def __init__(self, livemode=True):

        self.IA=IAFormes()
        self.__livemode=livemode

    def classification(self, s=50, Fichier='/Users/alexis/Desktop/Supop/Projet IETI/images/e1.bmp', Frame=None):#s=120

        if self.__livemode == False:

            self.c=Couleurim(Foldername=Fichier)
            img = Image.open(Fichier)

        else:
            Frame = Image.fromarray(Frame,mode="RGB")
            self.c = Couleurim(livemode=True, Frame=Frame)
            img = Frame

        img = img.convert('L')
        img=np.array(img)
        #print(img.shape)
        Xt=self.aquisi(img, s)
        #print(Xt.shape)
        P=self.IA.Proba(Xt)
        self.L={"Vide":"%0.2f" %P[0][0] , "Carré":"%0.2f" %P[0][1], "Cercle":"%0.2f" %P[0][2], "Triangle":"%0.2f" %P[0][3], "Pentagone":"%0.2f" %P[0][4], "Étoile":"%0.2f" %P[0][5]}
        pred=self.IA.Proba2(Xt)
        #print(list(self.L.items())[pred[0]+1])
        #print(self.c.couleur_proche(),self.c.nc)
        return [list(self.L.items())[pred[0]+1],self.c.couleur_proche(),self.c.nc]
        #self.IA.montreimage(0, [Xt])
        #self.c.affichage()



    def classi2(self, s=50, Fichier='/Users/alexis/Desktop/Supop/Projet IETI/images/e1.bmp', Frame=None):#s=120

        if self.__livemode == False:

            self.c=Couleurim(Foldername=Fichier)
            img = Image.open(Fichier)

        else:
            Frame = Image.fromarray(Frame,mode="RGB")
            #self.c = Couleurim(livemode=True, Frame=Frame)##
            img = Frame

        img = img.convert('L')
        img=np.array(img)
        #print(img.shape)
        Xt=self.aquisi(img, s)
        #print(Xt.shape)
        #P=self.IA.Proba(Xt)##
        #self.L={"Vide":"%0.2f" %P[0][0] , "Carré":"%0.2f" %P[0][1], "Cercle":"%0.2f" %P[0][2], "Triangle":"%0.2f" %P[0][3], "Pentagone":"%0.2f" %P[0][4], "Étoile":"%0.2f" %P[0][5]}##
        pred=self.IA.Proba2(Xt)
        #print(list(self.L.items())[pred[0]+1])
        #print(self.c.couleur_proche(),self.c.nc)
        return pred
        #self.IA.montreimage(0, [Xt])
        #self.c.affichage()
    def resize(self, image, l, m):

        image=Image.fromarray(np.uint8((image)))
        image.thumbnail((l,m))#/!\.shape=(51,64)
        return np.array(image)

    def seuil(self, imNB, s=120):

        return np.where(imNB<s, 0, imNB)

    def aquisi(self, im, s):

        (n,p)=im.shape
        im=self.seuil(im, s)
        im=self.resize(im, 64, 64)
        T=[im]
        T=np.array(T)
        T=np.reshape(T,(1, -1))
        return T

    def afficheinfo(self):

        return self.L, self.c.couleur_proche()









class Window(QWidget):



    def __init__(self, parent=None):
        super().__init__(parent)
        uic.loadUi("interface_graphique.ui", self)

    #tab=fonctiond'Alexis (tab[bleu, rouge, jaune, carre, triangle, rond])
        self.boolcouleur1 = 0##
        self.boolcouleur2 = 0
        self.boolcouleur3 = 0
        self.boolforme1 = 0
        self.boolforme2 = 0
        self.boolforme3 = 0
        self.boolchoix1 = 0 #la piece qui passe correspond au choix 1
        self.boolchoix2 = 0
        self.boolchoix3 = 0
        self.cp1 = 0
        self.cp2 = 0
        self.cp3 = 0
        self.tab1 = [0,0]
        self.tab2 = [0,0]
        self.tab3 = [0,0]##

        self.marche.clicked.connect(self.marcheCl)
        self.arret.clicked.connect(self.fin)


        self.cancelButton.clicked.connect(self.CancelFeed)
        self.cB.currentIndexChanged.connect(self.traitim)
        self.Worker1 = Worker1()
        self.Worker1.start()
        self.Worker1.ImageUpdate.connect(self.ImageUpdateSlot)#actualisation avec le pic#connect si machin est vrais alor arg est fait
        self.Worker2 = Worker2()
        self.Worker2.start()
        self.Worker2.PrediUpdate.connect(self.PrediUpdateSlot)
        self.Worker1.frameUpdate.connect(self.Worker2.pr)
        self.horizontalSlider.valueChanged.connect(self.changet)
        self.horizontalSlider_2.valueChanged.connect(self.changettr1)

        self.Worker2.tab = [1,3]
        self.Worker2.boolcouleur1 = 0
        self.Worker2.boolcouleur2 = 0
        self.Worker2.boolcouleur3 = 0
        self.Worker2.boolforme1 = 0
        self.Worker2.boolforme2 = 0
        self.Worker2.boolforme3 = 0
        self.Worker2.boolchoix1 = 0 #la piece qui passe correspond au choix 1
        self.Worker2.boolchoix2 = 0
        self.Worker2.boolchoix3 = 0
        self.Worker2.cp1 = 0
        self.Worker2.cp2 = 0
        self.Worker2.cp3 = 0
        # self.Worker2.tab1 = [0,0]
        # self.Worker2.tab2 = [0,0]
        # self.Worker2.tab3 = [0,0]
        self.Worker2.tab1=[[0,0,0],[0,0,0,0,0]]
        self.Worker2.tab2=[[0,0,0],[0,0,0,0,0]]
        self.Worker2.tab3=[[0,0,0],[0,0,0,0,0]]



        self.Worker2.detection()
    def CancelFeed(self):

        self.Worker2.stop()
        self.Worker1.stop()

    def changet(self):

        self.Worker1.timacsses(self.horizontalSlider.value())
        self.time_label.setText("%d s" %self.horizontalSlider.value())

    def changeim(self,c):

        self.Worker1.trait(c)

    def changettr1(self):

        self.Worker1.traitth1(self.horizontalSlider_2.value())
        self.Worker2.traitth1(self.horizontalSlider_2.value())

    # def changettr2(self):
    #     self.Worker1.traitth2(self.horizontalSlider_3.value())
    def ImageUpdateSlot(self, Image):

        self.label.setPixmap(QPixmap.fromImage(Image))

    def PrediUpdateSlot(self,pred):

        self.nbpiece1.setText(str(self.Worker2.cp1))
        self.nbpiece2.setText(str(self.cp2))
        self.nbpiece3.setText(str(self.cp3))
        self.Worker2.detection()
        self.label_3.setText(str(pred[0]))
        self.nclabel.setText("Couleur : " + str(pred[1]))
        self.clabel.setStyleSheet("background-color:rgb("+str(pred[2][0])+","+str(pred[2][1])+","+str(pred[2][2])+")")

    def traitim(self,val):

        self.Worker1.trait(val)



    def fin(self):
        self.a = 1

    def marcheCl(self):
        self.Worker2.tab1=[[0,0,0],[0,0,0,0,0]]
        if self.forme1.isChecked():
            if self.rond1.isChecked():
                    self.Worker2.tab1[1][1]=1
            if self.carre1.isChecked():
                    self.Worker2.tab1[1][0]=1
            if self.triangle1.isChecked():
                    self.Worker2.tab1[1][2]=1
            if self.pentagone1.isChecked():
                    self.Worker2.tab1[1][3]=1
            if self.etoile1.isChecked():
                    self.Worker2.tab1[1][4]=1
        if self.couleur1.isChecked():
            if self.rouge1.isChecked():
                    self.Worker2.tab1[0][0]=1
            if self.vert1.isChecked():
                    self.Worker2.tab1[0][1]=1
            if self.bleu1.isChecked():
                    self.Worker2.tab1[0][2]=1

        self.Worker2.tab2=[[0,0,0],[0,0,0,0,0]]
        if self.forme2.isChecked():
            if self.rond2.isChecked():
                    self.Worker2.tab2[1][1]=1
            if self.carre2.isChecked():
                    self.Worker2.tab2[1][0]=1
            if self.triangle2.isChecked():
                    self.Worker2.tab2[1][2]=1
            if self.pentagone2.isChecked():
                    self.Worker2.tab2[1][3]=1
            if self.etoile2.isChecked():
                    self.Worker2.tab2[1][4]=1
        if self.couleur2.isChecked():
            if self.rouge2.isChecked():
                    self.Worker2.tab2[0][0]=1
            if self.vert2.isChecked():
                    self.Worker2.tab2[0][1]=1
            if self.bleu2.isChecked():
                    self.Worker2.tab2[0][2]=1

        self.Worker2.tab3=[[0,0,0],[0,0,0,0,0]]
        self.Worker2.tabchoice3=[0,0]
        if self.forme3.isChecked():
            if self.rond3.isChecked():
                    self.Worker2.tab3[1][1]=1
            if self.carre3.isChecked():
                    self.Worker2.tab3[1][0]=1
            if self.triangle3.isChecked():
                    self.Worker2.tab3[1][2]=1
            if self.pentagone3.isChecked():
                    self.Worker2.tab3[1][3]=1
            if self.etoile3.isChecked():
                    self.Worker2.tab3[1][4]=1
        if self.couleur3.isChecked():
            if self.rouge3.isChecked():
                    self.Worker2.tab3[0][0]=1
            if self.vert3.isChecked():
                    self.Worker2.tab3[0][1]=1
            if self.bleu3.isChecked():
                    self.Worker2.tab3[0][2]=1


        self.m = 1
"""    def marcheCl(self):
        if self.choix1.isChecked():
            if self.couleur1.isChecked():
                if self.bleu1.isChecked():
                     self.Worker2.tab1[0]= 1
                elif self.rouge1.isChecked():
                    self.Worker2.tab1[0]=2
                else :
                     self.Worker2.tab1[0]=3
            if self.forme1.isChecked():
                if self.carre1.isChecked():
                     self.Worker2.tab1[1]=1
                elif self.triangle1.isChecked():
                     self.Worker2.tab1[1]=2
                else :
                     self.Worker2.tab1[1]=3
        if self.choix2.isChecked():
            if self.couleur2.isChecked():
                if self.bleu2.isChecked():
                     self.Worker2.tab2[0]=1
                elif self.rouge2.isChecked():
                     self.Worker2.tab2[0]=2
                else :
                     self.Worker2.tab2[0]=3
            if self.forme2.isChecked():
                if self.carre2.isChecked():
                     self.Worker2.tab2[1]=1
                elif self.triangle2.isChecked():
                     self.Worker2.tab2[1]=2
                else :
                     self.Worker2.tab2[1]=3
        if self.choix3.isChecked():
            if self.couleur3.isChecked():
                if self.bleu3.isChecked():
                     self.Worker2.tab3[0]=1
                elif self.rouge3.isChecked():
                     self.Worker2.tab3[0]=2
                else :
                     self.Worker2.tab3[0]=3
            if self.forme3.isChecked():
                if self.carre3.isChecked():
                     self.Worker2.tab3[1]=1
                elif self.triangle3.isChecked():
                     self.Worker2.tab3[1]=2
                else :
                     self.Worker2.tab3[1]=3
        self.m = 1"""









class Worker1(QThread):

    ImageUpdate = pyqtSignal(QImage)
    frameUpdate = pyqtSignal(np.ndarray)

    def run(self):

        self.timact=2
        self.ThreadActive = True
        self.traitement=2
        self.th1=120
        self.th2=120
        #Capture = cv2.VideoCapture(0)





        #Variables
        hCam = ueye.HIDS(0)             #0: first available camera;  1-254: The camera with the specified camera ID
        sInfo = ueye.SENSORINFO()
        cInfo = ueye.CAMINFO()
        pcImageMemory = ueye.c_mem_p()
        MemID = ueye.int()
        rectAOI = ueye.IS_RECT()
        pitch = ueye.INT()
        nBitsPerPixel = ueye.INT(24)    #24: bits per pixel for color mode; take 8 bits per pixel for monochrome
        channels = 3                    #3: channels for color mode(RGB); take 1 channel for monochrome
        m_nColorMode = ueye.INT()		# Y8/RGB16/RGB24/REG32
        bytes_per_pixel = int(nBitsPerPixel / 8)
        #---------------------------------------------------------------------------------------------------------------------------------------
        print("START")
        print()


        # Starts the driver and establishes the connection to the camera
        nRet = ueye.is_InitCamera(hCam, None)
        if nRet != ueye.IS_SUCCESS:
            print("is_InitCamera ERROR")

        # Reads out the data hard-coded in the non-volatile camera memory and writes it to the data structure that cInfo points to
        nRet = ueye.is_GetCameraInfo(hCam, cInfo)
        if nRet != ueye.IS_SUCCESS:
            print("is_GetCameraInfo ERROR")

        # You can query additional information about the sensor type used in the camera
        nRet = ueye.is_GetSensorInfo(hCam, sInfo)
        if nRet != ueye.IS_SUCCESS:
            print("is_GetSensorInfo ERROR")

        nRet = ueye.is_ResetToDefault( hCam)
        if nRet != ueye.IS_SUCCESS:
            print("is_ResetToDefault ERROR")

        # Set display mode to DIB
        nRet = ueye.is_SetDisplayMode(hCam, ueye.IS_SET_DM_DIB)

        # Set the right color mode
        if int.from_bytes(sInfo.nColorMode.value, byteorder='big') == ueye.IS_COLORMODE_BAYER:
            # setup the color depth to the current windows setting
            ueye.is_GetColorDepth(hCam, nBitsPerPixel, m_nColorMode)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("IS_COLORMODE_BAYER: ", )
            print("\tm_nColorMode: \t\t", m_nColorMode)
            print("\tnBitsPerPixel: \t\t", nBitsPerPixel)
            print("\tbytes_per_pixel: \t\t", bytes_per_pixel)
            print()

        elif int.from_bytes(sInfo.nColorMode.value, byteorder='big') == ueye.IS_COLORMODE_CBYCRY:
            # for color camera models use RGB32 mode
            m_nColorMode = ueye.IS_CM_BGRA8_PACKED
            nBitsPerPixel = ueye.INT(32)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("IS_COLORMODE_CBYCRY: ", )
            print("\tm_nColorMode: \t\t", m_nColorMode)
            print("\tnBitsPerPixel: \t\t", nBitsPerPixel)
            print("\tbytes_per_pixel: \t\t", bytes_per_pixel)
            print()

        elif int.from_bytes(sInfo.nColorMode.value, byteorder='big') == ueye.IS_COLORMODE_MONOCHROME:
            # for color camera models use RGB32 mode
            m_nColorMode = ueye.IS_CM_MONO8
            nBitsPerPixel = ueye.INT(8)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("IS_COLORMODE_MONOCHROME: ", )
            print("\tm_nColorMode: \t\t", m_nColorMode)
            print("\tnBitsPerPixel: \t\t", nBitsPerPixel)
            print("\tbytes_per_pixel: \t\t", bytes_per_pixel)
            print()

        else:
            # for monochrome camera models use Y8 mode
            m_nColorMode = ueye.IS_CM_MONO8
            nBitsPerPixel = ueye.INT(8)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("else")

        # Can be used to set the size and position of an "area of interest"(AOI) within an image
        nRet = ueye.is_AOI(hCam, ueye.IS_AOI_IMAGE_GET_AOI, rectAOI, ueye.sizeof(rectAOI))
        if nRet != ueye.IS_SUCCESS:
            print("is_AOI ERROR")

        width = rectAOI.s32Width
        height = rectAOI.s32Height

        # Prints out some information about the camera and the sensor
        print("Camera model:\t\t", sInfo.strSensorName.decode('utf-8'))
        print("Camera serial no.:\t", cInfo.SerNo.decode('utf-8'))
        print("Maximum image width:\t", width)
        print("Maximum image height:\t", height)
        print()

        #---------------------------------------------------------------------------------------------------------------------------------------

        # Allocates an image memory for an image having its dimensions defined by width and height and its color depth defined by nBitsPerPixel
        nRet = ueye.is_AllocImageMem(hCam, width, height, nBitsPerPixel, pcImageMemory, MemID)
        if nRet != ueye.IS_SUCCESS:
            print("is_AllocImageMem ERROR")
        else:
            # Makes the specified image memory the active memory
            nRet = ueye.is_SetImageMem(hCam, pcImageMemory, MemID)
            if nRet != ueye.IS_SUCCESS:
                print("is_SetImageMem ERROR")
            else:
                # Set the desired color mode
                nRet = ueye.is_SetColorMode(hCam, m_nColorMode)



        # Activates the camera's live video mode (free run mode)
        nRet = ueye.is_CaptureVideo(hCam, ueye.IS_DONT_WAIT)
        if nRet != ueye.IS_SUCCESS:
            print("is_CaptureVideo ERROR")

        # Enables the queue mode for existing image memory sequences
        nRet = ueye.is_InquireImageMem(hCam, pcImageMemory, MemID, width, height, nBitsPerPixel, pitch)
        if nRet != ueye.IS_SUCCESS:
            print("is_InquireImageMem ERROR")
        else:
            print("Press cancel to leave the programm")

        #---------------------------------------------------------------------------------------------------------------------------------------
        temp=time.time()
        # Continuous image display
        while(nRet == ueye.IS_SUCCESS):

            # In order to display the image in an OpenCV window we need to...
            # ...extract the data of our image memory
            array = ueye.get_data(pcImageMemory, width, height, nBitsPerPixel, pitch, copy=False)

            bytes_per_pixel = int(nBitsPerPixel / 8)

            # ...reshape it in an numpy array...
            frame = np.reshape(array,(height.value, width.value, bytes_per_pixel))

            # ...resize t                        he image by a half
            #frame = cv2.resize(frame,(0,0),fx=0.5, fy=0.5)

        #---------------------------------------------------------------------------------------------------------------------------------------
            #Include image data processing here

        #---------------------------------------------------------------------------------------------------------------------------------------

            #...and finally display it
            #cv2.imshow("SimpleLive_Python_uEye_OpenCV", frame)





            FlippedImage = cv2.flip(frame, 1)
            FlippedImage=FlippedImage[:,:,:3]
            #FlippedImage = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2RGB)
            #FlippedImage = cv2.cvtColor(FlippedImage, cv2.COLOR_RGB2BGR)

            if self.traitement==2:

                NBI = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2GRAY)
                _ , NBI = cv2.threshold(NBI, int((self.th1*255)/100), 255, cv2.THRESH_BINARY)
                NBI = cv2.cvtColor(NBI, cv2.COLOR_GRAY2BGR)
                FlippedImage = cv2.bitwise_and(FlippedImage,NBI)


            if self.traitement==1:

                FlippedImage = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2GRAY)

            if self.traitement==3:

                FlippedImage  = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2HSV)
                hsv = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2HSV)
                h,s,v = cv2.split(hsv)
                ret_h, th_h = cv2.threshold(h,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)#otsu choisi un trehol a la moitier des valeurs de l'histogramme
                ret_s, th_s = cv2.threshold(s,0,255,cv2.THRESH_BINARY+cv2.THRESH_OTSU)
                #Fusion th_h et th_s
                th = cv2.bitwise_or(th_h,th_s)
                #Ajouts de bord à l'image
                bordersize=50
                th = cv2.copyMakeBorder(th, top=bordersize, bottom=bordersize, left=bordersize, right=bordersize, borderType= cv2.BORDER_CONSTANT, value=[0,0,0] )
                #Remplissage des contours
                im_floodfill = th.copy()
                h, w = th.shape[:2]
                mask = np.zeros((h+2, w+2), np.uint8)
                cv2.floodFill(im_floodfill, mask, (0,0), 255)
                im_floodfill_inv = cv2.bitwise_not(im_floodfill)
                th = th | im_floodfill_inv
                #Enlèvement des bord de l'image
                th=th[bordersize: len(th)-bordersize,bordersize: len(th[0])-bordersize]
                resultat=cv2.bitwise_and(FlippedImage,FlippedImage,mask=th)
                # cv2.imwrite("im_floodfill.png",im_floodfill)
                # cv2.imwrite("th.png",th)
                # cv2.imwrite("resultat.png",resultat)
                # FlippedImage=cv2.merge((th_h,th_s,th_v))
                FlippedImage = resultat
                FlippedImage  = cv2.cvtColor(FlippedImage, cv2.COLOR_HSV2BGR)

            if self.traitement==4:

                #FlippedImage = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2GRAY)
                gray = cv2.GaussianBlur(FlippedImage, (5, 5), 0)
                #thresh=cv2.Canny(FlippedImage, self.th1,self.th1*2)
                thresh=cv2.Laplacian(gray,cv2.CV_8U,ksize=5)
                FlippedImage =thresh



            if temp+self.timact<time.time():

                updImage = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2RGB)
                #Image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
                #FlippedImage = cv2.flip(Image, 1)
                #npim=np.array(FlippedImage).astype(np.uint8)
                # imia=np.concatenate([npim,tz])
                # np.save("/Users/alexis/Desktop/imiai", imia)
                # print("okokokokokokokokok")
                # self.prediction=b.classification(Frame=imia)
                # print(type(FlippedImage))
                self.frameUpdate.emit(updImage)
                temp += self.timact


            if self.traitement==6:

                hsv  = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2HSV)
                h,s,v= cv2.split(hsv)
                ret_h, th_h = cv2.threshold(h,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
                ret_s, th_s = cv2.threshold(s,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
                hsv=cv2.merge((th_h,th_s,v))
                brgImage = cv2.cvtColor(hsv, cv2.COLOR_HSV2BGR)
                gray = cv2.cvtColor(brgImage, cv2.COLOR_BGR2GRAY)
                #  apply thresholding on the gray image to create a binary image
                _,thresh = cv2.threshold(gray,0,255,cv2.THRESH_BINARY_INV+cv2.THRESH_OTSU)
                #gray = cv2.GaussianBlur(gray, (5, 5), 0)
                #thresh=cv2.Canny(FlippedImage, self.th1,self.th1*2)
                # find the contours
                contours, _ = cv2.findContours(thresh,cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

                for i in range(len(contours)):

                    # take the first contour
                    cnt = contours[i]
                    # compute the bounding rectangle of the contour
                    x,y,w,h = cv2.boundingRect(cnt)
                    # draw contour
                    img = cv2.drawContours(FlippedImage,[cnt],contourIdx=-1, color=(0, 255, 255), thickness=2, lineType=cv2.LINE_AA)
                    # thresh=cv2.cvtColor(thresh,cv2.COLOR_GRAY2BGR)
                    # img = cv2.drawContours(thresh,[cnt],0,(0,255,255),2)
                    # draw the bounding rectangle
                    img = cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),2)
                FlippedImage =img


            if self.traitement==5:

                FlippedImage = cv2.GaussianBlur(FlippedImage, (5, 5), 0)
                FlippedImage = cv2.Canny(FlippedImage, self.th1,self.th1*2)

            FlippedImage = cv2.cvtColor(FlippedImage, cv2.COLOR_BGR2RGB)
            ConvertToQtFormat = QImage(FlippedImage.data, FlippedImage.shape[1], FlippedImage.shape[0], QImage.Format_RGB888)#Format_Mono)#
            Pic = ConvertToQtFormat.scaled(640,512,Qt.KeepAspectRatio)#640, 480, Qt.KeepAspectRatio)
            self.ImageUpdate.emit(Pic)#cree le signal qui permet d'actualiser les data
            # Press q if you want to end the loop
            if self.ThreadActive==False:
                break

        #---------------------------------------------------------------------------------------------------------------------------------------

        # Releases an image memory that was allocated using is_AllocImageMem() and removes it from the driver management
        ueye.is_FreeImageMem(hCam, pcImageMemory, MemID)

        # Disables the hCam camera handle and releases the data structures and memory areas taken up by the uEye camera
        ueye.is_ExitCamera(hCam)

        # Destroys the OpenCv windows
        #cv2.destroyAllWindows()

        print()
        print("END")


    def stop(self):
        self.ThreadActive=False
        self.quit()#arrete l'exectution de la classe.

    def timacsses(self,ti):

        self.timact = ti

    def trait(self,t):

        self.traitement = t

    def traitth1(self,t):

        self.th1 = t

    def traitth2(self,t):

        self.th2 = t



class Worker2(QThread):

    PrediUpdate = pyqtSignal(list)
    #predfinale = pyqtSignal(int)

    def __init__(self):

        super().__init__()
        self.tz = np.zeros([304,1280,3]).astype(np.uint8)
        self.b = IAcouleurs()
        self.th1=120
        self.tab=[0,0]
        self.L=[]
        self.clf=[]


        time.sleep(10)
        ports = serial.tools.list_ports.comports()
        for port, desc, hwid in sorted(ports):
            print("{}: {}".format(port, desc))
            selectPort = input("Select a COM port : ")
        print(f"Port Selected : COM{selectPort}")
        self.serNuc = Serial('COM'+str(selectPort), 115200)


    def pr(self,Imagecv):

        npim = np.array(Imagecv).astype(np.uint8)
        #print(npim.shape)
        #imia = np.concatenate([npim,self.tz])
        imia=npim
        self.prediction = self.b.classification(Frame=imia,s=int((self.th1*255)/100))
        self.PrediUpdate.emit(self.prediction)

        maxcoul=self.prediction[2][0]
        for k in range(len(self.prediction[2])):
            if self.prediction[2][k]>=maxcoul:
                couleur_rgb_finale = k
        #print(couleur_rgb_finale)
        


        pred=self.b.classi2(Frame=imia,s=int((self.th1*255)/100))
        if pred!=-1:
            self.clf.append(couleur_rgb_finale)
            self.L.append(pred[0])

        elif len(self.L)>1:
            prL=[0,0,0,0,0]
            for k in range(len(self.L)):
                prL[self.L[k]]+=1
            prL=np.array(prL)
            pre=prL.argmax()
            self.tab=[self.clf[-2],pre]
            print("prediction :")
            print(self.tab)
            #self.predfinale.emit(pre)
            self.L=[]
            self.clf=[]

    def stop(self):
        self.serNuc.close()
        self.quit()#arrete l'exectution de la classe.
    def traitth1(self,t):

        self.th1 = t

    def detection(self):

        #print(self.tab1)
        #print(self.tab)
        






        if self.tab1[0]!=[0,0,0] or self.tab1[1]!=[0,0,0,0,0]:
            if self.tab1[1]==[0,0,0,0,0]:
                if self.tab1[0][self.tab[0]]==1:#/!\-1?
                    self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                    print("envoyé1")
                    # while self.serNuc.inWaiting() == 0:
                    #     pass
                    # data_rec = self.serNuc.read(4)  # bytes
                    # print(str(data_rec))
                    self.cp1 += 1#compteur de piece
                    #self.nbpiece1.setText(str(self.cp1))
            if self.tab1[0]==[0,0,0]:
                if self.tab1[1][self.tab[1]]==1:#/!\-1?
                    self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                    print("envoyé1")
                    # while self.serNuc.inWaiting() == 0:
                    #     pass
                    # data_rec = self.serNuc.read(4)  # bytes
                    # print(str(data_rec))
                    self.cp1 += 1#compteur de piece
                    #self.nbpiece1.setText(str(self.cp1))
            else:
                if self.tab1[0][self.tab[0]]==1:#-1?
                    if self.tab1[1][self.tab[1]]==1:
                        self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                        
                        # while self.serNuc.inWaiting() == 0:
                        #     pass
                        # data_rec = self.serNuc.read(4)  # bytes
                        # print(str(data_rec))
                        self.cp1 += 1#compteur de piece
                        #self.nbpiece1.setText(str(self.cp1))





        if self.tab2[0]!=[0,0,0] or self.tab2[1]!=[0,0,0,0,0]:
            if self.tab2[1]==[0,0,0,0,0]:
                if self.tab2[0][self.tab[0]]==1:#/!\-1?
                    self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1

                    # while self.serNuc.inWaiting() == 0:
                    #     pass
                    # data_rec = self.serNuc.read(4)  # bytes
                    # print(str(data_rec))
                    self.cp1 += 1#compteur de piece
                    #self.nbpiece1.setText(str(self.cp1))
            if self.tab2[0]==[0,0,0]:
                if self.tab2[1][self.tab[1]]==1:#/!\-1?
                    self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1

                    # while self.serNuc.inWaiting() == 0:
                    #     pass
                    # data_rec = self.serNuc.read(4)  # bytes
                    # print(str(data_rec))
                    self.cp1 += 1#compteur de piece
                    #self.nbpiece1.setText(str(self.cp1))
            else:
                if self.tab2[0][self.tab[0]]==1:#-1?
                    if self.tab2[1][self.tab[1]]==1:
                        self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                        # while self.serNuc.inWaiting() == 0:
                        #     pass
                        # data_rec = self.serNuc.read(4)  # bytes
                        # print(str(data_rec))
                        self.cp1 += 1#compteur de piece
                        #self.nbpiece1.setText(str(self.cp1))






        if self.tab3[0]!=[0,0,0] or self.tab3[1]!=[0,0,0,0,0]:
            if self.tab3[1]==[0,0,0,0,0]:
                if self.tab3[0][self.tab[0]]==1:#/!\-1?
                    self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                    print("envoyé3")
                    # while self.serNuc.inWaiting() == 0:
                    #     pass
                    # data_rec = self.serNuc.read(4)  # bytes
                    # print(str(data_rec))
                    self.cp1 += 1#compteur de piece
                    #self.nbpiece1.setText(str(self.cp1))
            if self.tab3[0]==[0,0,0]:
                if self.tab3[1][self.tab[1]]==1:#/!\-1?
                    self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                    print("envoyé3")
                    # while self.serNuc.inWaiting() == 0:
                    #     pass
                    # data_rec = self.serNuc.read(4)  # bytes
                    # print(str(data_rec))
                    self.cp1 += 1#compteur de piece
                    #self.nbpiece1.setText(str(self.cp1))
            else:
                if self.tab3[0][self.tab[0]]==1:#-1?
                    if self.tab3[1][self.tab[1]]==1:
                        self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                        # while self.serNuc.inWaiting() == 0:
                        #     pass
                        # data_rec = self.serNuc.read(4)  # bytes
                        # print(str(data_rec))
                        self.cp1 += 1#compteur de piece
                        #self.nbpiece1.setText(str(self.cp1))
        """
        else:
            print("else")
            self.serNuc.write(bytes(str(0), 'ascii'))#commande moteur1
            while self.serNuc.inWaiting() == 0:
                pass
            data_rec = self.serNuc.read(4)  # bytes
            print(str(data_rec))
        
        """



"""


        if self.tab1[0][self.tab[0]-1]==1 or self.tab1[0]==[0, 0, 0] :
            print('ok1')
            if self.tab1[1][self.tab[1]]==1:
                self.serNuc.write(bytes(str(1), 'ascii'))#commande moteur1
                print('ok')
                while self.serNuc.inWaiting() == 0:
                    pass
                data_rec = self.serNuc.read(4)  # bytes
                print(str(data_rec))
                self.cp1 += 1#compteur de piece
                #self.nbpiece1.setText(str(self.cp1))
        if self.tab2[0][self.tab[0]-1]==1 or self.tab2[0]==[0,0,0] :
            if self.tab2[1][self.tab[1]-1]==1 or (self.tab2[1]==[0,0,0,0,0] and  self.tab2[0]!=[0,0,0]) :
                self.serNuc.write(bytes(str(2), 'ascii'))#commande moteur2
                while self.serNuc.inWaiting() == 0:
                    pass
                data_rec = self.serNuc.read(4)  # bytes
                print(str(data_rec))
                self.cp2 += 1#compteur de piece
                #self.nbpiece1.setText(str(self.cp1))
        if self.tab3[0][self.tab[0]-1]==1 or self.tab3[0]==[0,0,0] :
            if self.tab3[1][self.tab[1]-1]==1 or (self.tab3[1]==[0,0,0,0,0] and  self.tab3[0]!=[0,0,0]) :
                self.serNuc.write(bytes(str(3), 'ascii'))#commande moteur3
                while self.serNuc.inWaiting() == 0:
                    pass
                data_rec = self.serNuc.read(4)  # bytes
                print(str(data_rec))
                self.cp3 += 1#compteur de piece
                #self.nbpiece1.setText(str(self.cp1))


"""

if __name__ == "__main__":



    """ tik = PerpetualTimer(1, detection)
    tik.start()"""
    app = QApplication(sys.argv)

    win = Window()
    win.show()
    app.exec()
