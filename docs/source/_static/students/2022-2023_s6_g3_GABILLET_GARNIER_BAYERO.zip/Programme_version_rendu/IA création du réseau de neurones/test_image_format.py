# -*- coding: utf-8 -*-
"""
Created on Mon May 15 10:16:32 2023

@author: Travail
"""

import numpy as np
import matplotlib.pyplot as plt
from PIL import Image

# Ce code est inséré dans le programme global dans la boucle while. Pour chaque image prise par la caméré, on effectue toutes ces opérations pour avoir le bon format d'image pour le réseau de neurone 

image = np.load("init.npy", allow_pickle = True) #image exemple

image = image[:,:,0:3]

imageConvertie_1 = Image.fromarray(image)

imageGris = imageConvertie_1.convert("L")
# Convertion de l'image en array numpy
image_array = np.array(imageGris)

# Seuillage de l'image pour n'avoir que la forme sur un fond noir
for i in range(512):
    for j in range(640):
        if image_array[i,j] < 120:
            image_array[i,j] = 0

# Compression de l'image
imageConvertie_2 = Image.fromarray(image_array)
imageCompress = imageConvertie_2.resize((64,64))
image_array_2 = np.array(imageCompress)