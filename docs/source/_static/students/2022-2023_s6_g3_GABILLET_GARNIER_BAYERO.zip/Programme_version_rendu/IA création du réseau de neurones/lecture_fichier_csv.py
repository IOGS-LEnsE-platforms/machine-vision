# import pandas as pd
# #import cv2
# import matplotlib.pyplot as plt
# import numpy as np
# from sklearn.model_selection import train_test_split
 
# dataset_path = 'C:/Users/Travail/Desktop/DEEP LEARNING/App_chiffres/Images/train.csv'
# image_size=(28,28) #add 3 if RGB image
 
# def load():
    
#     data = pd.read_csv(dataset_path)
    
#     pixels = data['Pixels'].tolist()
#     width, height= 28, 28 ,# add depth 3 if RGB image
#     faces = []
    
#     for pixel_sequence in pixels:
#         face = [int(pixel) for pixel in pixel_sequence.split(' ')]
#         face = np.asarray(face).reshape(width, height,) #add depth if RGB image
#         a = face
#         face = np.resize(face.astype('uint8'),image_size)
#         faces.append(face.astype('float32'))
    
#     faces = np.asarray(faces)
#     A = faces
#     faces = np.expand_dims(faces, -1)
    
#     return faces, A
 
# faces,A = load()
# plt.imshow(A[0].astype("uint8"))

# Importation des bibliotèques
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
from PIL import Image

from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score

# Importation des paramètres
A = np.load("parametres_poids.npy", allow_pickle = True)
A = [A[0],A[1],A[2]]

B = np.load("parametres_bias.npy", allow_pickle = True)
B = [B[0],B[1],B[2]]


# Création du modèle
mlp = MLPClassifier(hidden_layer_sizes=(256,128), activation='logistic', solver='sgd', learning_rate='constant', learning_rate_init=1e-4, max_iter = 1, random_state=0, tol=5e-5, verbose=True, momentum=0.9)

# Initialisation dess paramètres dans le modèle (obligatoire)
x_init = np.zeros((6,4096))
y_init = [1,2,3,4,5,6]

mlp.fit(x_init, y_init)

# On attribue les paramètres au modèle
mlp.intercepts_ = B
mlp.coefs_ = A


# Test sur une image
data = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/hexagone.csv').iloc[100,1:].values
data = [data]

predi=mlp.predict(data)

if predi == 1:
    print("rond")

if predi == 2:
    print("triangle")
    
if predi == 3:
    print("carre")

if predi == 4:
    print("pentagone")

if predi == 5:
    print("hexagone")

if predi == 6:
    print("etoile")





