# -*- coding: utf-8 -*-

# Importation des bibliotèques
from sklearn import datasets
from sklearn.neural_network import MLPClassifier
from sklearn.metrics import accuracy_score
from sklearn.model_selection import train_test_split

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from tqdm import tqdm

# Ce code permet de chercher le modèle pour le réseau de neurone et d'en exporter les paramètres pour pouvoir les utiliser pour le projet par la suite

pourcentage_dataset = 70
nb_pct = int(pourcentage_dataset*10000/100)

# Importation des base de données
data_rond = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/rond.csv').iloc[:nb_pct,1:].values
print("rond")
data_triangle = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/triangle.csv').iloc[:nb_pct,1:].values
print("triangle")
data_carre = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/carre.csv').iloc[:nb_pct,1:].values
print("carre")
data_pentagone = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/pentagone.csv').iloc[:nb_pct,1:].values
print("pentagone")
data_hexagone = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/hexagone.csv').iloc[:nb_pct,1:].values
print("hexagone")
data_etoile = pd.read_csv('C:/Users/Travail/Desktop/1A IOGS/Projet IETI/programme/IA/base_donnees/formes/etoile.csv').iloc[:nb_pct,1:].values


liste = [data_rond, data_triangle, data_carre, data_pentagone, data_hexagone, data_etoile]

# Récupération des données ( x--> données du modèle ; y--> données de vérification)
x = np.zeros((6*nb_pct,4096))
y = np.zeros(6*nb_pct)

for i in tqdm(range(6)):
    y[nb_pct*i:nb_pct*(i+1)] = i
    x[nb_pct*i:nb_pct*(i+1),:] = liste[i]

# Affichage d'une image du dataset
test = x[100,:]
test = test.reshape((64,64))
plt.imshow(test)

# Séparation des données d'entrainement et des données de test
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.5, shuffle=True)

# Initialisation du modèle
print("Lancement du modèle")
mlp = MLPClassifier(hidden_layer_sizes=(256,128), activation='logistic', solver='sgd', learning_rate='constant', learning_rate_init=1e-3, max_iter = 100, random_state=0, tol=5e-5, verbose=True, momentum=0.9)
"""
hidden_layer_sizes : Nombre de couche et nombre de neurone par couche (10,10) --> 2 couches cachées de 10 neurone chacune
activation : Fonction d'activation pour connaitre la probabilité d'appartenance de la donnée à un groupe --> 'logistic' = sigmoïd
solver : Methode de determination de correction de l'erreur --> 'sgd' = descente du gradient
learning_rate : technique d'apprentissage
learning_rate_init : Le taux d'apprentissage initial utilisé. Contrôle la taille du pas dans la mise à jour des poids (paramètres)
max_iter : Nombre d'itération maximum avant l'arret de l'entrainement
random_state : Initialise aléatoirement la valeur de tous les paramètres du réseau de neurone (la seed)
tol : Tolérance de l'optimisation de l'erreur. Différence minimum de l'erreur entre 10 itérations avant que l'entrainement s'arrète.
verbose : Print l'avancement de l'entrainement du modèle
momentum : Coefficient d'amortissement de la fonction de descente de gradient
"""

# Entrainement du modèle
print("Lancement de l'entrainement")
mlp.fit(x_train, y_train)

# Prédiction de la référence des données test
print("Lancement des prédictions")
predi=mlp.predict(x_test)

# Précision obtenue avec les données test en les comparant aux vraies classe
print(accuracy_score(y_test, predi))

print("Training set score: %f" % mlp.score(x_train, y_train))
print("Test set score: %f" % mlp.score(x_test, y_test))

hyper_parametres = mlp.get_params()
parametres_poids = mlp.coefs_
parametres_bias = mlp.intercepts_

# Affichage de la courbe de cout en fonction des itérations
plt.figure()
plt.plot(mlp.loss_curve_)
plt.show()

# # Affichage des poids des paramètres
# fig, axes = plt.subplots(4, 4)
# vmin, vmax = mlp.coefs_[0].min(), mlp.coefs_[0].max()
# for coef, ax in zip(mlp.coefs_[0].T, axes.ravel()):
#     ax.matshow(coef.reshape(8, 8), vmin=0.5 * vmin, vmax=0.5 * vmax)
#     # Enlève les axes et les graduations
#     ax.set_xticks(())
#     ax.set_yticks(())
# plt.show()
# 
# # Affichage des images avec les mauvaises prédictions
# fausse_image = []
# for k in range(len(x_test)):
#     if predi[k] != y_test[k]:
#         fausse_image.append(k)

# plt.imshow(digits.images[int(len(y)/2)+fausse_image[0]])
# plt.show()

        
print("Calcul de la matrice de confusion")
from sklearn.metrics import confusion_matrix, ConfusionMatrixDisplay

y_pred = mlp.predict(x_test)
cm = confusion_matrix(y_test, y_pred)

cm_display = ConfusionMatrixDisplay(cm).plot()
plt.show()

#Création d'un fichier .npy (fichier enregistrant un tableau numpy directement) pour stocker les paramètres 
np.save("parametres_p.npy",parametres_poids,allow_pickle = True)
np.save("parametres_b.npy",parametres_bias,allow_pickle = True)
