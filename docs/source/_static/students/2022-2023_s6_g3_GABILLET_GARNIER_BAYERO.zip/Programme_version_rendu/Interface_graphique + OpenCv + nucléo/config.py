# -*- coding: utf-8 -*-
"""
Created on Thu May 11 17:43:56 2023

@author: Julien Garnier / Gabillet Thomas
"""

# import numpy as np 

# choice = True # True couleur, false forme
# choice_IA = False # Activation ou non de l'IA

detecteur = ""

remplissage_color = {'ROUGE': 0, 'ORANGE': 0, 'JAUNE': 0, 'VERT_CLAIR': 0, 
            'VERT_FONCE' : 0, 'BLEU_CLAIR': 0, 'BLEU_FONCE': 0,
             'VIOLET': 0, "ROSE" : 0, "MARRON" : 0, "INDEFINI" : 0} 
color = 0

remplissage_shape = {'TRIANGLE': 0, 'CARRE': 0, 'RECTANGLE': 0,
           'PENTAGONE': 0, 'HEXAGONE' : 0, 'ETOILE': 0, 'CERCLE': 0} 
shape = 0

current_slider = 120

choice = True

# frame = np.load("init.npy", allow_pickle = True)