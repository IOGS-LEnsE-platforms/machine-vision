# -*- coding: utf-8 -*-
"""
Created on Mon Mar  6 11:12:08 2023

@author: Julien
"""

import serial
import serial.tools.list_ports

# Initialisation d'une liaison série avec la Nucléo
serial_port = serial.tools.list_ports.comports()
for port in serial_port:
    print(f"{port.name} // {port.device} // D={port.description}")
    

serial_com = 5
serial_com_name = 'COM'+str(serial_com)

# Ouverture du port série
ser = serial.Serial(serial_com_name, baudrate=115200)



#Envoi de données (char) à la Nucléo
while (True):
    print("entrer couleur : ") # envoyer, r, v ou b pour pousser le rouge (1), vert(2), bleu(3)
    c = input()
    c = bytes(c, 'utf-8')
    ser.write(c)    

# Lecture du charactère envoyer que Nucléo retourne ("r", "v", "b") 
# Attention 2 charactère à lire car "r\n" : pas oublier charactère de fin de ligne
rec_data_nucleo = ser.readline(2)
print(f'Rec = {rec_data_nucleo}')
ser.close()  