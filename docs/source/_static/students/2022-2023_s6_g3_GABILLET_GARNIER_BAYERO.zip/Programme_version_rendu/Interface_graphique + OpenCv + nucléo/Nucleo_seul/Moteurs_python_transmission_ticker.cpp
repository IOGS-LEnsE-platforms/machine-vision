#include "mbed.h"
#include <cstdint>
#include <iostream>
#include <random>


#define DET_T 0.01 // 10ms
#define NB_OBJET                                                               \
  20 // NB objets à traiter, longueur de la liste en cours de traitement

// 1er ticker déclenchement servo
// Temps de déclenchement en s si div par 100
#define N_1 230
#define N_2 485
#define N_3 790

// 2eme ticker retour servo
#define N_retour 140

int recept_objet=0; //1, 2, 3  

Ticker toggle_ticker;

// Ticker 1
//  On établit une liste de longueur finie qui contient les états détectés en
//  cours et leur temps qui décroit de N à 0.
int objet_liste[NB_OBJET] = {
    0}; // [1, 2, 0, 0, 1, 3...] valeur pour pousser moteur 1 moteur 2 ou 3. La
        // valeur 0 indique, aucune affectation
int n_liste[NB_OBJET] = {0}; // [300, 500, 0, 0, 500...] : liste des compteurs
                             // de temps qui décroissent à 0.
// contient les temps N associés aux états occupés détecté. A la détection la
// valeur est N puis décroit toutes les 10ms jusqu'à 0 où l'état devient
// disponible
//  A 0 l'état est libre

// Ticker 2
//  Retour
int retour_liste[NB_OBJET] = {0};
int n_retour_liste[NB_OBJET] = {0}; // [300, 500, 0, 0, 500...] : liste des
                                    // compteurs de temps qui décroissent à 0.

int delay = 0;

// MOTEUR
// alimentation en 5,7V continu sur le L298
// Un courant de 0,7-0,8A est créé
PwmOut clock_pwm(A1);
DigitalOut reset(A2);
DigitalOut half(A3);
DigitalOut sens_clockwise(A4);
DigitalOut enable(A5);

DigitalIn bouton(D7); // Bouton convoyeur

DigitalIn detecteur(D13);

// Test envoi données leds
DigitalOut led(D4);
UnbufferedSerial my_pc(USBTX, USBRX);
char data;
void ISR_my_pc_reception(void);

// SERVO 1
//  Delivre 3,3V en PWM
PwmOut servo_mot1(D8);
DigitalIn bouton_servo(D3);

// SERVO 2
//  Delivre 3,3V en PWM
PwmOut servo_mot2(D9);

// SERVO 3
//  Delivre 3,3V en PWM
PwmOut servo_mot3(D10);

// 1er ticker déclenchement servo
void init_compteur(int etat_libre) {

  if (objet_liste[etat_libre] == 1) {
    n_liste[etat_libre] = N_1;
  }

  if (objet_liste[etat_libre] == 2) {
    n_liste[etat_libre] = N_2;
  }

  if (objet_liste[etat_libre] == 3) {
    n_liste[etat_libre] = N_3;
  }
}

void decrementation() // décrémente, le compteur de n à 0
{
  int i = 0;
  for (i = 0; i < NB_OBJET; i++) {
    if (n_liste[i] !=
        0) // && objet_liste[i]!=0 pas besoin car pas besoin de cette vérif car
           // la décrementation arrive à 0 automatiquement pas nég
    {
      n_liste[i]--;
    }
    if (n_retour_liste[i] !=
        0) // && retour_liste[i]!=0 pas besoin car pas besoin de cette vérif car
           // la décrementation arrive à 0 automatiquement pas nég
    {
      n_retour_liste[i]--;
    }
  }
  // delai de détection au passage du cube, = temps de passage pour ne pas
  // continuellement détecté quand le cube est devant
  if (delay != 0)
    delay--;
}

// 2eme ticker retour

int check_etat_libre() {
  int i = 0; // indice de check d'un état libre
  while (objet_liste[i] != 0) {
    i++;
  }

  return i;
}

void init_compteur_retour(int i) { n_retour_liste[i] = N_retour; }

int main() {

  // 100khZ

  // MOTEUR PAS à PAS
  clock_pwm.period_ms(1);
  clock_pwm.write(0.5);

  enable = 1; // Mise en marche enable et reset obligatoire
  reset = 1;  // Initialisation obligatoire
  half = 1;
  sens_clockwise = 1; // 1 sens horaire 0 sens anti-horaire

  int a = 0;

  // SERVOMOTEUR
  int i, time = 1500;
  servo_mot1.period_ms(10); // Initialisation période
  // servo_mot.pulsewidth_us(1500);   // Initialisation en position 0
  servo_mot2.period_ms(10); // Initialisation période
  servo_mot3.period_ms(10); // Initialisation période

  my_pc.baud(115200);
  my_pc.attach(&ISR_my_pc_reception, UnbufferedSerial::RxIrq);

  toggle_ticker.attach(&decrementation, DET_T);
  while (1) {
   
    if (detecteur == 1 && delay == 0) {

        delay = 100;
        // TEst génration couleur aléatoire
        // int random;
        // int max = 3;
        // int min = 1;
        // random = rand() % (max - min + 1) + min;
        
        
        // choisir 1  (et N_1) ou // choisir 2  (et N_2) ou // choisir 3  (et N_3)
        // selon le servomoteur choisi

        int etat_libre = check_etat_libre();
        objet_liste[etat_libre] = recept_objet;
        // On a trouvé une case libre i dans n_liste : aucun objet en cours

        init_compteur(etat_libre);
    }

    for (i = 0; i < NB_OBJET; i++) {
      if (n_liste[i] == 0 && objet_liste[i] != 0) {

        if (objet_liste[i] == 1) {
          servo_mot1.pulsewidth_us(2400);
          init_compteur_retour(i);
          objet_liste[i] = 0;
          retour_liste[i] = 1;
        }

        if (objet_liste[i] == 2) {
          servo_mot2.pulsewidth_us(2400);
          init_compteur_retour(i);
          objet_liste[i] = 0;
          retour_liste[i] = 2;
        }

        if (objet_liste[i] == 3) {
          servo_mot3.pulsewidth_us(2400);
          init_compteur_retour(i);
          objet_liste[i] = 0;
          retour_liste[i] = 3;
        }
      }
    }

    for (i = 0; i < NB_OBJET; i++) {
      if (n_retour_liste[i] == 0 && retour_liste[i] != 0) {
        if (retour_liste[i] == 1) {
          servo_mot1.pulsewidth_us(1000);
          retour_liste[i] = 0;
        }

        if (retour_liste[i] == 2) {
          servo_mot2.pulsewidth_us(1000);
          retour_liste[i] = 0;
        }

        if (retour_liste[i] == 3) {
          servo_mot3.pulsewidth_us(1000);
          retour_liste[i] = 0;
        }
      }
    }
  }
}


void ISR_my_pc_reception(void) {
    my_pc.read(&data, 1); // get the received byte
    if (data == 'r')
    {
    recept_objet = 1;
    }
    if (data == 'v')
    {
    recept_objet = 2;
    }
    if (data == 'b')
    {
    recept_objet = 3;
    }
    my_pc.write(&data, 1); // echo of the byte received
}

