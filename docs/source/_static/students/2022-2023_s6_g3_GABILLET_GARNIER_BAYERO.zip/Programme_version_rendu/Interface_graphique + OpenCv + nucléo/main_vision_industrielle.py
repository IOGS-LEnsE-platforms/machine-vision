# -*- coding: utf-8 -*-

"""
Programme de l'interface graphique sous PyQt5 pour commander le banc
industrielle de détection de formes et de couleurs
@author: Julien
"""

__authors__ = ("Julien Garnier / Thomas Gabillet")
__copyright__ = "SupOptique"
__date__ = "2023-22-05"
__version__= "3.0"

# =============================================================================
# IMPORTATION DES BIBLIOTHEQUES POUR L'INTERFACE GRAPHIQUE AVEC PYQT5
# =============================================================================
import sys
from PyQt5 import QtCore, QtGui, QtWidgets
import time
import cv2
import numpy as np

import config



# =============================================================================
# VARIABLES GLOBALES ENTRE LES PROGRAMMES
# =============================================================================

#Globales booléens
global choice # True couleur, false forme
choice = True
global choice_IA
choice_IA = False

global marche # Valeurs on ou off des moteurs, de l'application
marche = 0
global servo_retour # Valeurs retour des servomoteurs (1 = retour en position initiale)
retour = 0

#Globales pour OpenCv et la détection
global taille_max # Taille max de détection pour OpenCv (Surface px²)
global vitesse # Vitesse du moteur A CHANGER


#Globales pour le tri dans les 3 boîtes
global color # Liste des 3 couleurs à récuperer pour les 3 boîtes à trier
color = ['ROUGE', 'VERT_FONCE', 'BLEU_FONCE']
global shape # Liste des 3 formes à récuperer pour les 3 boîtes à trier
shape = ['CERCLE', 'CARRE', 'HEXAGONE']
global pourcentage_box # Pourcentage de remplissage des boîtes (liste) pour les 3 boîtes


# =============================================================================
# Taille de la fenêtre
# =============================================================================

# L_WINDOW = QtWidgets.QApplication.desktop().width()
# H_WINDOW = QtWidgets.QApplication.desktop().height()
# print(f"Résolution de l'écran : {L_WINDOW}x{H_WINDOW}")

L_WINDOW = 1920
H_WINDOW = 1080

# L_WINDOW=3840
# H_WINDOW=2160

MAX = 10

# =============================================================================
# Création de la connection entre la nucléo et l'ordinateur
# =============================================================================

import serial
import serial.tools.list_ports

serial_com = 5
serial_com_name = 'COM'+str(serial_com)

# Ouvre le serial port
ser = serial.Serial(serial_com_name, baudrate=115200)



#---------------------------------------------------------------------------------------------------------------------------------------

#Libraries
from pyueye import ueye


#---------------------------------------------------------------------------------------------------------------------------------------

#Nos bibliothèques
from detection_formes_seuil_config import detection_formes, affichage_continu_traitement_formes

from detection_couleur_config import detection_couleurs, affichage_continu_traitement_couleurs


class WorkerThread(QtCore.QObject):
    signalContinu = QtCore.pyqtSignal(str, QtGui.QImage) #Init fonction émise à période régulière 
 
    def __init__(self):
        super().__init__()
        global pourcentage_box
        pourcentage_box = [0,0,0]# Initialisation des pourcentages de remplissage des boîtes à 0
 
        
    @QtCore.pyqtSlot() 
    def run(self):
        """Boucle infini générée avec un signal continu et permet de:
            - allumer la caméra et récupération de la frame
            - scruter pour détecter la forme/couleur
            - rafraîchissement des pourcentages dans l'application

        Returns
        -------
        None.

        """
        global choice, choice_IA
        global current_slider # Valeur du seuillage
        global pourcentage_box, marche
        
        lower=np.array([5,95, 170])# valeurs HSV min pour la couleur

        # lower=np.array([5,95, 120])# valeurs HSV min pour la couleur
        upper=np.array([255,255,255])
        
        #---------------------------------------------------------------------------------------------------------------------------------------
        # =============================================================================
        # INFOS_CAMERA : PAS_TOUCHER
        # =============================================================================
        #---------------------------------------------------------------------------------------------------------------------------------------
        
        #Variables
        hCam = ueye.HIDS(0)             #0: first available camera;  1-254: The camera with the specified camera ID
        sInfo = ueye.SENSORINFO()
        cInfo = ueye.CAMINFO()
        pcImageMemory = ueye.c_mem_p()
        MemID = ueye.int()
        rectAOI = ueye.IS_RECT()
        pitch = ueye.INT()
        nBitsPerPixel = ueye.INT(24)    #24: bits per pixel for color mode; take 8 bits per pixel for monochrome
        channels = 3                    #3: channels for color mode(RGB); take 1 channel for monochrome
        m_nColorMode = ueye.INT()		# Y8/RGB16/RGB24/REG32
        bytes_per_pixel = int(nBitsPerPixel / 8)
        #---------------------------------------------------------------------------------------------------------------------------------------
        
        print("START")
        
        
        # Starts the driver and establishes the connection to the camera
        nRet = ueye.is_InitCamera(hCam, None)
        if nRet != ueye.IS_SUCCESS:
            print("is_InitCamera ERROR")
        
        # Reads out the data hard-coded in the non-volatile camera memory and writes
        # it to the data structure that cInfo points to
        nRet = ueye.is_GetCameraInfo(hCam, cInfo)
        if nRet != ueye.IS_SUCCESS:
            print("is_GetCameraInfo ERROR")
        
        # You can query additional information about the sensor type used in the camera
        nRet = ueye.is_GetSensorInfo(hCam, sInfo)
        if nRet != ueye.IS_SUCCESS:
            print("is_GetSensorInfo ERROR")
        
        nRet = ueye.is_ResetToDefault( hCam)
        if nRet != ueye.IS_SUCCESS:
            print("is_ResetToDefault ERROR")
        
        # Set display mode to DIB
        nRet = ueye.is_SetDisplayMode(hCam, ueye.IS_SET_DM_DIB)
        
        # Set the right color mode
        if int.from_bytes(sInfo.nColorMode.value, byteorder='big') == ueye.IS_COLORMODE_BAYER:
            # setup the color depth to the current windows setting
            ueye.is_GetColorDepth(hCam, nBitsPerPixel, m_nColorMode)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("IS_COLORMODE_BAYER: ", )
            print("\tm_nColorMode: \t\t", m_nColorMode)
            print("\tnBitsPerPixel: \t\t", nBitsPerPixel)
            print("\tbytes_per_pixel: \t\t", bytes_per_pixel)
            print()
        
        elif int.from_bytes(sInfo.nColorMode.value, byteorder='big') == ueye.IS_COLORMODE_CBYCRY:
            # for color camera models use RGB32 mode
            m_nColorMode = ueye.IS_CM_BGRA8_PACKED
            nBitsPerPixel = ueye.INT(32)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("IS_COLORMODE_CBYCRY: ", )
            print("\tm_nColorMode: \t\t", m_nColorMode)
            print("\tnBitsPerPixel: \t\t", nBitsPerPixel)
            print("\tbytes_per_pixel: \t\t", bytes_per_pixel)
            print()
        
        elif int.from_bytes(sInfo.nColorMode.value, byteorder='big') == ueye.IS_COLORMODE_MONOCHROME:
            # for color camera models use RGB32 mode
            m_nColorMode = ueye.IS_CM_MONO8
            nBitsPerPixel = ueye.INT(8)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("IS_COLORMODE_MONOCHROME: ", )
            print("\tm_nColorMode: \t\t", m_nColorMode)
            print("\tnBitsPerPixel: \t\t", nBitsPerPixel)
            print("\tbytes_per_pixel: \t\t", bytes_per_pixel)
            print()
        
        else:
            # for monochrome camera models use Y8 mode
            m_nColorMode = ueye.IS_CM_MONO8
            nBitsPerPixel = ueye.INT(8)
            bytes_per_pixel = int(nBitsPerPixel / 8)
            print("else")
        
        # Can be used to set the size and position of an "area of interest"(AOI) within an image
        nRet = ueye.is_AOI(hCam, ueye.IS_AOI_IMAGE_GET_AOI, rectAOI, ueye.sizeof(rectAOI))
        if nRet != ueye.IS_SUCCESS:
            print("is_AOI ERROR")
        
        width = rectAOI.s32Width
        height = rectAOI.s32Height
        
        # Prints out some information about the camera and the sensor
        print("Camera model:\t\t", sInfo.strSensorName.decode('utf-8'))
        print("Camera serial no.:\t", cInfo.SerNo.decode('utf-8'))
        print("Maximum image width:\t", width)
        print("Maximum image height:\t", height)
        print()
        
        #---------------------------------------------------------------------------------------------------------------------------------------
        
        # Allocates an image memory for an image having its dimensions defined by width and height and its color depth defined by nBitsPerPixel
        nRet = ueye.is_AllocImageMem(hCam, width, height, nBitsPerPixel, pcImageMemory, MemID)
        if nRet != ueye.IS_SUCCESS:
            print("is_AllocImageMem ERROR")
        else:
            # Makes the specified image memory the active memory
            nRet = ueye.is_SetImageMem(hCam, pcImageMemory, MemID)
            if nRet != ueye.IS_SUCCESS:
                print("is_SetImageMem ERROR")
            else:
                # Set the desired color mode
                nRet = ueye.is_SetColorMode(hCam, m_nColorMode)
        
        
        
        # Activates the camera's live video mode (free run mode)
        nRet = ueye.is_CaptureVideo(hCam, ueye.IS_DONT_WAIT)
        if nRet != ueye.IS_SUCCESS:
            print("is_CaptureVideo ERROR")
        
        # Enables the queue mode for existing image memory sequences
        nRet = ueye.is_InquireImageMem(hCam, pcImageMemory, MemID, width, height, nBitsPerPixel, pitch)
        if nRet != ueye.IS_SUCCESS:
            print("is_InquireImageMem ERROR")
        else:
            print("Press q to leave the programm")
        
        
        # =============================================================================
        # PROJET : DETECTION FORMES ET COULEURS : OPENCV
        # =============================================================================
        #---------------------------------------------------------------------------------------------------------------------------------------
            
        #---------------------------------------------------------------------------------------------------------------------------------------
        "Initialisation avant la boucle de flux video"
        #Variable_detection
        
        #---------------------------------------------------------------------------------------------------------------------------------------
        
        if choice : #couleur
            config.remplissage_color = {'ROUGE': 0, 'ORANGE': 0, 'JAUNE': 0, 'VERT_CLAIR': 0, 
                        'VERT_FONCE' : 0, 'BLEU_CLAIR': 0, 'BLEU_FONCE': 0,
                         'VIOLET': 0, "ROSE" : 0, "MARRON" : 0, "INDEFINI" : 0} 
            # remplissage_color = {'ROUGE': 0, 'VERT': 0, 'BLEU': 0} 
            config.color = 0
           
        
        else: #Formes
            config.remplissage_shape = {'TRIANGLE': 0, 'CARRE': 0, 'RECTANGLE': 0,
                       'PENTAGONE': 0, 'HEXAGONE' : 0, 'ETOILE': 0, 'CERCLE': 0} 
        
            # remplissage = {'PENTAGONE': 0, 'CARRE': 0, 'CERCLE': 0} 
            config.shape = 0
            



        while(nRet == ueye.IS_SUCCESS):
            # In order to display the image in an OpenCV window we need to...
            # ...extract the data of our image memory
            array = ueye.get_data(pcImageMemory, width, height, nBitsPerPixel, pitch, copy=False)
        
            # bytes_per_pixel = int(nBitsPerPixel / 8)
        
            # ...reshape it in an numpy array...
            frame = np.reshape(array,(height.value, width.value, bytes_per_pixel))

            # ...resize the image by a half
            frame = cv2.resize(frame,(0,0),fx=0.5, fy=0.5)
            
# =============================================================================
#             Affichage dans des fenêtres externes avec OpenCv de la frame
# =============================================================================            
            
            # if choice : #Couleurs
            #     affichage_continu_traitement_couleurs(frame)
            # elif choice==False and choice_IA==True :#Detection de formes avec l'IA
            #     pass
            # else:
            #     affichage_continu_traitement_formes(frame)
         
        #---------------------------------------------------------------------------------------------------------------------------------------
           
            #Calculs et fonctions de traitement d'images
            #Rognage et seuillage dans la fonction "Seuillage", "img_convoyeur"
            # if cv2.waitKey(20) == ord('t'):
            #     config.detecteur = 'd'
            
# =============================================================================
#             Rognage et fonctions de traitement d'images avec les fonctions detection_color/shape
#             Puis détection et renvoie de la forme/couleur
# =============================================================================        
            
            detecteur = ser.readline(1) # attention "\n" du C
            detecteur_value = detecteur.decode() # on reçoit "d" = détection par la Nucléo lorsque l'objet passe devant le détecteur, global partagée aux fichiers
            # print(activation)
            config.detecteur = detecteur_value 
            print("démarrage")
            if config.detecteur == 'd' : # on reçoit "d" = détection par la Nucléo lorsque l'objet passe devant le détecteur, global partagée aux fichiers
            # globale créée dans le module de l'appli dans la méthode de récpetion de la donnée par la nucléo
            
                image_screenshot = frame
                # cv2.imshow('screen', image_screenshot)

# =============================================================================
#               Detection de couleur avec OpenCv
# =============================================================================
                
                if choice:#Detection de couleur avec OpenCv
                    #Lecture image à la détection
                    config.color, config.remplissage_color = detection_couleurs(image_screenshot, config.remplissage_color)
                    # cv2.imshow('acquisition', image_screenshot)
                    # print(f"couleur : {color} , nb rempli : {remplissage}")
                    print(f"couleur : {config.color},  {config.remplissage_color}")
        
# =============================================================================
#               Detection de la forme avec l'IA
# =============================================================================
                     
                elif choice==False and choice_IA==True :#Detection de formes avec l'IA
                    pass

# =============================================================================
#               Detection de la forme avec OpenCv
# =============================================================================

                else:#Detection de formes avec OpenCv
                    #Detection par la cellule TOR
                    #Lecture image à la détection
                    config.shape, config.remplissage_shape = detection_formes(image_screenshot, config.remplissage_shape)
                    # cv2.imshow('acquisition', image_screenshot)
                    # print(f"forme : {shape} , nb rempli : {remplissage}")
                    print(f"forme : {config.shape}, {config.remplissage_shape}")
                    
# =============================================================================
# Envoi aux moteurs de pousser la forme/couleurs détectée, pour pousser dans les boîtes
# =============================================================================
                # le module détection de la caméra reçoit la valeur "d" globale pour changer la valeur de config.color
                if choice == True:
                    if config.color == color[0]:
                        ser.write(bytes('1', 'utf-8'))
                        print('moteur 1 enclenché')
                        pourcentage_box[0] = config.remplissage_color[config.color]
                    if config.color == color[1]:
                        ser.write(bytes('2', 'utf-8'))
                        print('moteur 2 enclenché')
                        pourcentage_box[1] = config.remplissage_color[config.color]
                    if config.color == color[2]:
                        ser.write(bytes('3', 'utf-8'))
                        print('moteur 3 enclenché') 
                        pourcentage_box[2] = config.remplissage_color[config.color]
                    # if config.color == color[0]:
                    #     ser.write(bytes('1', 'utf-8'))
                    #     print('moteur 1 enclenché')
                    #     if MAX+1 < config.remplissage_color[config.color]:
                    #         pourcentage_box[0] = config.remplissage_color[config.color]
                    #     # else :
                    #     #     pourcentage_box[0] = 100
                    #     #     marche = 0
                    #     #     ser.write(bytes('s', 'utf-8'))
                    #     #     print("Moteurs à l'arrêt")
                  
                    # if config.color == color[1]:
                    #     ser.write(bytes('2', 'utf-8'))
                    #     print('moteur 2 enclenché')
                    #     if MAX+1 < config.remplissage_color[config.color]:
                    #         pourcentage_box[1] = config.remplissage_color[config.color]
                    #     else :
                    #         pourcentage_box[1] = 100
                    #         marche = 0
                    #         ser.write(bytes('s', 'utf-8'))
                    #         print("Moteurs à l'arrêt")
                
                    # if config.color == color[2]:
                    #     ser.write(bytes('3', 'utf-8'))
                    #     print('moteur 3 enclenché') 
                    #     if MAX < config.remplissage_color[config.color]:
                    #         pourcentage_box[2] = config.remplissage_color[config.color]
                    #     else :
                    #         pourcentage_box[2] = 100
                    #         marche = 0
                    #         ser.write(bytes('s', 'utf-8'))
                    #         print("Moteurs à l'arrêt")
                else:
                    if config.shape == shape[0]:
                        ser.write(bytes('1', 'utf-8'))
                        print('moteur 1 enclenché')
                        pourcentage_box[0] = config.remplissage_shape[config.shape]
                    if config.shape == shape[1]:
                        ser.write(bytes('2', 'utf-8'))
                        print('moteur 2 enclenché')
                        pourcentage_box[1] = config.remplissage_shape[config.shape]
                    if config.shape == shape[2]:
                        ser.write(bytes('3', 'utf-8'))
                        print('moteur 3 enclenché') 
                        pourcentage_box[2] = config.remplissage_shape[config.shape]
               
                
            config.detecteur = ''

            
            #Définition d'une zone de détection
            # y1 = 200
            # y2 = 400
            # x1 = 100
            # x2 = 600
            # img_convoyeur = frame[y1:y2, x1:x2]
            img_convoyeur = frame
            
# =============================================================================
# Affichage dans l'appli du flux video par thread : frame = camera en continue
# ou image_screenshot = pour la photo acquise
# =============================================================================
            if choice == True:
                image_hsv=cv2.cvtColor(img_convoyeur, cv2.COLOR_BGR2HSV)# changment de RGB à HSV
                #height2, width2, ret = image_hsv.shape
                #Seuillage pour créer un masque selon couleur dans l'espace HSV
                #frame_threshold = cv.inRange(frame_HSV, (low_H, low_S, low_V), (high_H, high_S, high_V))
                lower[2]=config.current_slider
                masque=cv2.inRange(image_hsv, lower, upper)
                image_hsv=cv2.blur(image_hsv, (7,7))
                
                image2=cv2.bitwise_and(frame, frame, mask=masque)
                
                rgbImage = cv2.cvtColor(image2, cv2.COLOR_BGR2RGB)

            else: 
                img_gray_conv = cv2.cvtColor(img_convoyeur, cv2.COLOR_BGR2GRAY)

                img_gray_conv = cv2.blur(img_gray_conv, (4, 4))

                # seuil = cv2.getTrackbarPos("seuil", "Seuillage")
                seuil = config.current_slider
                
                # Seuillage binaire tel que niveau_de_gris > 40 on met en blanc=255 les formes
                ret, thresh = cv2.threshold(
                    img_gray_conv, seuil, 255, cv2.THRESH_BINARY)
                
                rgbImage = cv2.cvtColor(thresh, cv2.COLOR_BGR2RGB)
            
            h, w, ch = rgbImage.shape
            bytesPerLine = ch * w
            
            convertToQtFormat = QtGui.QImage(rgbImage.data, w, h, bytesPerLine, QtGui.QImage.Format_RGB888)
            
            p = convertToQtFormat.scaled(L_WINDOW//2, H_WINDOW//2, QtCore.Qt.KeepAspectRatio)
            
            # Boucle continue de refresh de l'interface
            self.signalContinu.emit("Acquisition", p) # Toutes les 0.5 sec, on émet Acquissiton lors de la réalisation de la fonction signal continu
            # time.sleep(0.01)# Temps de refresh de 0.5s
            # if marche == 0:
            #     break
            
# =============================================================================
# stopper les moteurs lorsque l'une des boîtes et pleines
# =============================================================================

            # on stoppe les moteurs, quand la boîte est pleine et on bloque à 100%
            for i in range(0,2):
                if pourcentage_box[i]>=100:
                    marche = 0
                    
         
        
        
        #---------------------------------------------------------------------------------------------------------------------------------------
        "Fin du flux video"
        
        # Releases an image memory that was allocated using is_AllocImageMem() and removes it from the driver management
        ueye.is_FreeImageMem(hCam, pcImageMemory, MemID)
        
        # Disables the hCam camera handle and releases the data structures and memory areas taken up by the uEye camera
        ueye.is_ExitCamera(hCam)
        
        # Destroys the OpenCv windows
        cv2.destroyAllWindows()
        
        print()
        print("END")  


                    

    
class Ui_MainWindow(object):
    """Classe permettant de créer une interface graphique avec Pyqt5,
    pour controler le banc industriel et la détection de formes ou couleurs
    
    méthodes : 
    ----------
        setupUi(self, MainWindow) : Initialisation graphique de l'interface
        
    """
       
    def setupUi(self, MainWindow):
        """Initialisation graphique de l'interface
        
        """
        #Disposition de la MainWindow et taille
        MainWindow.setWindowTitle("ViewSort Application - Commande du projet vision industrielle")
        MainWindow.setFixedSize(L_WINDOW, H_WINDOW)
        MainWindow.setWindowFlag(QtCore.Qt.FramelessWindowHint) # suppr la barre haute et basse de l'appli, pour un plein écran
        
        # Positionne le coin haut gauche de la fenêtre, dans le coin haut gauche de l'écran
        MainWindow.move(0, 0)
        MainWindow.setStyleSheet("background-color: rgb(45, 45, 45);")
        
        
        # Initialisation d'une émission continue de signal pour une app continue qui refresh à période régulière
        self.worker = WorkerThread()
        self.workerThread = QtCore.QThread()
        self.workerThread.started.connect(self.worker.run)  # Init du worker run()
        self.worker.signalContinu.connect(self.signalContinu)  # connection de l'émetteur/receveur
        self.worker.moveToThread(self.workerThread)  # Déplacement du Worker object au Thread object
        
        #Démarrage du thread
        self.workerThread.start()
                
        self.centralwidget = QtWidgets.QWidget(MainWindow)
        self.centralwidget.setObjectName("centralwidget")
        self.verticalLayout = QtWidgets.QVBoxLayout(self.centralwidget)
        self.verticalLayout.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout.setSpacing(0)
        self.verticalLayout.setObjectName("verticalLayout")
        
    # =============================================================================
    # Barre du haut 
    # =============================================================================
        self.Top_Bar = QtWidgets.QFrame(self.centralwidget)
        self.Top_Bar.setMaximumSize(QtCore.QSize(L_WINDOW, H_WINDOW//12))
        self.Top_Bar.setStyleSheet("background-color: rgb(35, 35, 35);")
        self.Top_Bar.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.Top_Bar.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Top_Bar.setObjectName("Top_Bar")
        
        # Bouton Valider les paramètres
        self.horizontalLayout = QtWidgets.QHBoxLayout(self.Top_Bar)
        self.horizontalLayout.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout.setSpacing(0)
        self.horizontalLayout.setObjectName("horizontalLayout")
        
        # Cadre du bouton valider
        self.frame_toggle = QtWidgets.QFrame(self.Top_Bar)
        self.frame_toggle.setMaximumSize(QtCore.QSize(L_WINDOW//10, H_WINDOW//12))
        self.frame_toggle.setStyleSheet("background-color: rgb(85, 170, 255);")
        self.frame_toggle.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_toggle.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_toggle.setObjectName("frame_toggle")

        self.verticalLayout_2 = QtWidgets.QVBoxLayout(self.frame_toggle)
        self.verticalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.verticalLayout_2.setSpacing(0)
        self.verticalLayout_2.setObjectName("verticalLayout_2")
        
        # PushButton valider
        self.Button_valider = QtWidgets.QPushButton(self.frame_toggle)
        sizePolicy = QtWidgets.QSizePolicy(QtWidgets.QSizePolicy.Expanding, QtWidgets.QSizePolicy.Expanding)
        sizePolicy.setHorizontalStretch(0)
        sizePolicy.setVerticalStretch(0)
        sizePolicy.setHeightForWidth(self.Button_valider.sizePolicy().hasHeightForWidth())
        self.Button_valider.setSizePolicy(sizePolicy)
        self.Button_valider.setStyleSheet("#Button_valider{\n"
                                          "background-color: rgb(0, 170, 255);\n"
                                          "color: rgb(255, 255, 255);\n"
                                          "border: 0px solid;\n"
                                          "}\n"
                                          "#Button_valider:pressed{\n"
                                          "background-color: rgb(0, 146, 219);\n"
                                          "border: 0px solid;\n"
                                          "}"
                                          "#Button_valider:hover{\n"
                                          "background-color: rgb(0, 146, 219);\n"
                                          "border: 0px solid;\n"
                                          "}")
        
        self.Button_valider.setObjectName("Button_valider")
        self.Button_valider.clicked.connect(self.valider)
        
        self.verticalLayout_2.addWidget(self.Button_valider)
        self.horizontalLayout.addWidget(self.frame_toggle)
        
        self.frame_top = QtWidgets.QFrame(self.Top_Bar)
        self.frame_top.setEnabled(True)
        self.frame_top.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame_top.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame_top.setObjectName("frame_top")
        
        # Logo
        self.logo = QtWidgets.QLabel(self.Top_Bar)
        self.logo.setGeometry(QtCore.QRect(L_WINDOW-L_WINDOW//3, -H_WINDOW//8, L_WINDOW//3, H_WINDOW//3))
        self.logo.setText("")
        self.logo.setPixmap(QtGui.QPixmap(".//Projet_interface//Logo/Logo_vector2.png"))
        self.logo.setScaledContents(True)
        self.logo.setObjectName("logo")
        
        
        # Vitesse
        self.label_vitesse = QtWidgets.QLabel(self.frame_top)
        self.label_vitesse.setGeometry(QtCore.QRect(L_WINDOW//50, H_WINDOW//48, L_WINDOW//9, H_WINDOW//24))
        self.label_vitesse.setStyleSheet("color: rgb(255, 255, 255);\n"
                                         "font:  8pt \"Calibri\";\n"
                                         "")
        self.label_vitesse.setObjectName("label_vitesse")
        
        self.spin_vitesse = QtWidgets.QSpinBox(self.frame_top)
        self.spin_vitesse.setGeometry(QtCore.QRect(L_WINDOW//7, H_WINDOW//48, L_WINDOW//12, H_WINDOW//24))
        self.spin_vitesse.setStyleSheet("background-color: rgb(0, 170, 255);\n"
                                        "color: rgb(255, 255, 255);\n"
                                        "border-radius: 5px\n"
                                        "")
        self.spin_vitesse.setMinimum(2)
        self.spin_vitesse.setProperty("value", 2)
        self.spin_vitesse.setObjectName("spin_vitesse")
        
        
        
        # Taille à détecter
        self.label_taille = QtWidgets.QLabel(self.frame_top)
        self.label_taille.setGeometry(QtCore.QRect(L_WINDOW//4, H_WINDOW//48, L_WINDOW//8, H_WINDOW//24))
        self.label_taille.setStyleSheet("color: rgb(255, 255, 255);\n"
                                   "font:  8pt \"Calibri\";\n"
                                   "")
        self.label_taille.setObjectName("label_taille")
        
        self.spin_taille = QtWidgets.QSpinBox(self.frame_top)
        self.spin_taille.setGeometry(QtCore.QRect(L_WINDOW//3+L_WINDOW//20, H_WINDOW//48, L_WINDOW//12, H_WINDOW//24))
        self.spin_taille.setStyleSheet("\n"
                                       "background-color: rgb(0, 170, 255);\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        self.spin_taille.setMaximum(5000)
        self.spin_taille.setProperty("value", 2000)
        self.spin_taille.setObjectName("spinBox_2")
    
    # =============================================================================
    # Fenetre centrale
    # =============================================================================
        #Encapsulation de layout et cadres pour mettre le stackedWidget(tourner les pages)   
        self.horizontalLayout.addWidget(self.frame_top)
        self.verticalLayout.addWidget(self.Top_Bar)
        self.Content = QtWidgets.QFrame(self.centralwidget)
        self.Content.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.Content.setFrameShadow(QtWidgets.QFrame.Raised)
        self.Content.setObjectName("Content")
        
        self.horizontalLayout_2 = QtWidgets.QHBoxLayout(self.Content)
        self.horizontalLayout_2.setContentsMargins(0, 0, 0, 0)
        self.horizontalLayout_2.setSpacing(0)
        self.horizontalLayout_2.setObjectName("horizontalLayout_2")
        self.frame = QtWidgets.QFrame(self.Content)
        self.frame.setFrameShape(QtWidgets.QFrame.StyledPanel)
        self.frame.setFrameShadow(QtWidgets.QFrame.Raised)
        self.frame.setObjectName("frame")
        
        
        # Tourner les pages avec un stackedWidget   
        self.stackedWidget = QtWidgets.QStackedWidget(self.frame)
        self.stackedWidget.setGeometry(QtCore.QRect(0, 0, L_WINDOW, H_WINDOW-H_WINDOW//12))
        self.stackedWidget.setStyleSheet("background-color: rgb(255, 255, 0);")
        self.stackedWidget.setObjectName("stackedWidget")
           
# =============================================================================
# Page 1 : Choix formes/couleurs      
# =============================================================================
        self.page_1 = QtWidgets.QWidget()
        self.page_1.setObjectName("page_1")
        self.stackedWidget.addWidget(self.page_1)
        #Fond 1
        self.Background_1 = QtWidgets.QLabel(self.page_1)
        self.Background_1.setGeometry(QtCore.QRect(0, 0, L_WINDOW, H_WINDOW-H_WINDOW//12))
        self.Background_1.setText("")
        self.Background_1.setPixmap(QtGui.QPixmap("./Projet_Interface/Fond/Plan de travail 1.png"))
        self.Background_1.setScaledContents(True)
        self.Background_1.setObjectName("Background_1")

        
        #Bouton de couleurs
        self.Button_color = QtWidgets.QPushButton(self.page_1)
        self.Button_color.setGeometry(QtCore.QRect(L_WINDOW//4-L_WINDOW//20, H_WINDOW//5, H_WINDOW//2, H_WINDOW//2))
        self.Button_color.setStyleSheet("#Button_color{\n"
                                        "background-color: transparent;\n"
                                        "border-image: url(.//Projet_interface//Bouton_couleurs//Bouton_couleurs.png);\n"
                                        "background : none;\n"
                                        "border : none;\n"
                                        "background-repeat : none;\n"
                                        "}\n"
                                        "#Button_color:pressed{\n"
                                        "border-image: url(.//Projet_interface//Bouton_couleurs//Bouton_couleurs_pressed.png);\n"
                                        "}"
                                        "#Button_color:hover{\n"
                                        "border-image: url(.//Projet_interface//Bouton_couleurs//Bouton_couleurs_pressed.png);\n"
                                        "}")
        self.Button_color.setText("")
        self.Button_color.setObjectName("Button_color")
        
        self.Button_color.clicked.connect(self.choice_color)


        #Bouton de formes
        self.Button_shape = QtWidgets.QPushButton(self.page_1)
        self.Button_shape.setGeometry(QtCore.QRect(L_WINDOW//2+L_WINDOW//20, H_WINDOW//5, H_WINDOW//2, H_WINDOW//2))
        self.Button_shape.setStyleSheet("#Button_shape{\n"
                                        "background-color: transparent;\n"
                                        "border-image: url(.//Projet_interface//Bouton_formes//bouton_forme.png);\n"
                                        "background : none;\n"
                                        "border : none;\n"
                                        "background-repeat : none;\n"
                                        "}\n"
                                        "#Button_shape:pressed{\n"
                                        "border-image: url(.//Projet_interface//Bouton_formes//bouton_forme_pressed.png);\n"
                                        "}"
                                        "#Button_shape:hover{\n"
                                        "border-image: url(.//Projet_interface//Bouton_formes//bouton_forme_pressed.png);\n"
                                        "}")
        self.Button_shape.setText("")
        self.Button_shape.setObjectName("Button_shape")
        
        #Clic sur le bouton forme, la méthode choice_shape est activée : choice=0
        self.Button_shape.clicked.connect(self.choice_shape)

        
# =============================================================================
# Page 2 : Couleurs 
# =============================================================================
        
        self.page_2 = QtWidgets.QWidget()
        self.page_2.setObjectName("page_2")
        self.stackedWidget.addWidget(self.page_2)
        #Fond 2
        self.Background_2 = QtWidgets.QLabel(self.page_2)
        self.Background_2.setGeometry(QtCore.QRect(0, 0, L_WINDOW, H_WINDOW-H_WINDOW//12))
        self.Background_2.setText("")
        self.Background_2.setPixmap(QtGui.QPixmap("./Projet_Interface/Fond/Plan de travail2.jpg"))
        self.Background_2.setScaledContents(True)
        self.Background_2.setObjectName("Background_2")
        
        
        # Image centrale du convoyeur
        self.img_convoyeur_1 = QtWidgets.QLabel(self.page_2)
        self.img_convoyeur_1.setGeometry(QtCore.QRect(-L_WINDOW//24, H_WINDOW//6, L_WINDOW+L_WINDOW//8, 5*(H_WINDOW//8)))
        self.img_convoyeur_1.setStyleSheet("background-color: transparent;\n"
                                           "background : none;\n"
                                           "\n"
                                           "")
        self.img_convoyeur_1.setText("")
        self.img_convoyeur_1.setPixmap(QtGui.QPixmap("./Projet_Interface/Convoyeur/convoyeur.png"))
        self.img_convoyeur_1.setScaledContents(True)
        self.img_convoyeur_1.setObjectName("img_convoyeur_1")
        
        
        
        #Boite 1      
        self.img_box2_1 = QtWidgets.QLabel(self.page_2)
        self.img_box2_1.setGeometry(QtCore.QRect(2*(L_WINDOW//3), H_WINDOW//48, L_WINDOW//9, H_WINDOW//4+H_WINDOW//23))
        self.img_box2_1.setStyleSheet("background-color: transparent;\n"
                                      "background : none;\n"
                                      "\n"
                                      "\n"
                                      "")
        self.img_box2_1.setText("")
        self.img_box2_1.setPixmap(QtGui.QPixmap("./Projet_Interface/Boite/boite.png"))
        self.img_box2_1.setScaledContents(True)
        self.img_box2_1.setObjectName("img_box2_1")
        
        
        #Boite 2
        self.img_box2_2 = QtWidgets.QLabel(self.page_2)
        self.img_box2_2.setGeometry(QtCore.QRect(L_WINDOW//2-L_WINDOW//20, H_WINDOW//2+H_WINDOW//11, L_WINDOW//9, H_WINDOW//4+H_WINDOW//23))
        self.img_box2_2.setStyleSheet("background-color: transparent;\n"
                                      "background : none;\n"
                                      "\n"
                                      "\n"
                                      "")
        self.img_box2_2.setText("")
        self.img_box2_2.setPixmap(QtGui.QPixmap("./Projet_Interface/Boite/boite.png"))
        self.img_box2_2.setScaledContents(True)
        self.img_box2_2.setObjectName("img_box2_2")
        
        
        #Boite 3
        self.img_box2_3 = QtWidgets.QLabel(self.page_2)
        self.img_box2_3.setGeometry(QtCore.QRect(L_WINDOW//3-L_WINDOW//10, H_WINDOW//48, L_WINDOW//9, H_WINDOW//4+H_WINDOW//23))
        self.img_box2_3.setStyleSheet("background-color: transparent;\n"
                                      "background : none;\n"
                                      "\n"
                                      "\n"
                                      "")
        self.img_box2_3.setText("")
        self.img_box2_3.setPixmap(QtGui.QPixmap("./Projet_Interface/Boite/boite.png"))
        self.img_box2_3.setScaledContents(True)
        self.img_box2_3.setObjectName("img_box2_3")
        
        
        #Definition de la combobox de la boite 1 pour choisir des couleurs
        self.comboBox2_1 = QtWidgets.QComboBox(self.page_2)
        self.comboBox2_1.setGeometry(QtCore.QRect(L_WINDOW//2+L_WINDOW//40, H_WINDOW//53, L_WINDOW//7, H_WINDOW//22))
        self.comboBox2_1.setStyleSheet("background-color: rgb(30, 24, 84);\n"
                                       "font: 8pt \"Calibri\";\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        #Associations d'images à chaque icon du combobox
        self.comboBox2_1.setObjectName("comboBox2_1")
        icon = QtGui.QIcon()
        icon.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/rouge.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon, "")
        icon1 = QtGui.QIcon()
        icon1.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/orange.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon1, "")
        icon2 = QtGui.QIcon()
        icon2.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/jaune.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon2, "")
        icon3 = QtGui.QIcon()
        icon3.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/vert_clair.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon3, "")
        icon4 = QtGui.QIcon()
        icon4.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/vert_fonce.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon4, "")
        icon5 = QtGui.QIcon()
        icon5.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/bleu_clair.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon5, "")
        icon6 = QtGui.QIcon()
        icon6.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/bleu_fonce.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon6, "")
        icon7 = QtGui.QIcon()
        icon7.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/violet.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon7, "")
        icon8 = QtGui.QIcon()
        icon8.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/rose.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon8, "")
        icon9 = QtGui.QIcon()
        icon9.addPixmap(QtGui.QPixmap("./Projet_Interface/Palette/marron.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox2_1.addItem(icon9, "")
        
        
        #Definition de la combobox de la boite 2 pour choisir des couleurs
        self.comboBox2_2 = QtWidgets.QComboBox(self.page_2)
        self.comboBox2_2.setGeometry(QtCore.QRect(L_WINDOW//2-L_WINDOW//5+L_WINDOW//120, H_WINDOW//3+H_WINDOW//2, L_WINDOW//7, H_WINDOW//22))
        self.comboBox2_2.setStyleSheet("background-color: rgb(30, 24, 84);\n"
                                       "font: 8pt \"Calibri\";\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        self.comboBox2_2.setObjectName("comboBox2_2")
        self.comboBox2_2.addItem(icon4, "")
        self.comboBox2_2.addItem(icon, "")
        self.comboBox2_2.addItem(icon1, "")
        self.comboBox2_2.addItem(icon2, "")
        self.comboBox2_2.addItem(icon3, "")
        self.comboBox2_2.addItem(icon5, "")
        self.comboBox2_2.addItem(icon6, "")
        self.comboBox2_2.addItem(icon7, "")
        self.comboBox2_2.addItem(icon8, "")
        self.comboBox2_2.addItem(icon9, "")
        
        
        #Definition de la combobox de la boite 3 pour choisir des couleurs
        self.comboBox2_3 = QtWidgets.QComboBox(self.page_2)
        self.comboBox2_3.setGeometry(QtCore.QRect(L_WINDOW//11, H_WINDOW//53, L_WINDOW//7, H_WINDOW//22))
        self.comboBox2_3.setStyleSheet("background-color: rgb(30, 24, 84);\n"
                                       "font: 8pt \"Calibri\";\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        self.comboBox2_3.setObjectName("comboBox2_3")
        self.comboBox2_3.addItem(icon6, "")
        self.comboBox2_3.addItem(icon, "")
        self.comboBox2_3.addItem(icon1, "")
        self.comboBox2_3.addItem(icon2, "")
        self.comboBox2_3.addItem(icon3, "")
        self.comboBox2_3.addItem(icon4, "")
        self.comboBox2_3.addItem(icon5, "")
        self.comboBox2_3.addItem(icon7, "")
        self.comboBox2_3.addItem(icon8, "")
        self.comboBox2_3.addItem(icon9, "")
        
        
        #Bouton start permettant de démarrer les moteurs (marche 1), Initialiser les pourcentages à zéros (boîtes vides)
        self.Button_start_2 = QtWidgets.QPushButton(self.page_2)
        self.Button_start_2.setGeometry(QtCore.QRect(L_WINDOW-L_WINDOW//10, H_WINDOW-H_WINDOW//4, L_WINDOW//12, L_WINDOW//12))
        self.Button_start_2.setStyleSheet("#Button_start_2{\n"
                                          "background-color: transparent;\n"
                                          "border-image: url(.//Projet_interface//Bouton_start//start2.png);\n"
                                          "background : none;\n"
                                          "border : none;\n"
                                          "background-repeat : none;\n"
                                          "}\n"
                                          "#Button_start_2:pressed{\n"
                                          "border-image: url(.//Projet_interface//Bouton_start//start2_pressed.png);\n"
                                          "}"
                                          "#Button_start_2:hover{\n"
                                          "border-image: url(.//Projet_interface//Bouton_start//start2_pressed.png);\n"
                                          "}")
        self.Button_start_2.setText("")
        self.Button_start_2.setObjectName("Button_start_2")
        self.Button_start_2.clicked.connect(self.meth_button_start)
        
        # Bouton page suivante : 
        self.Button_2to3 = QtWidgets.QPushButton(self.page_2)
        self.Button_2to3.setGeometry(QtCore.QRect(L_WINDOW-H_WINDOW//30, 0, H_WINDOW//30, H_WINDOW//30))
        self.Button_2to3.setStyleSheet("#Button_2to3{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_2to3:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next_pressed.png);\n"
                                       "}"
                                       "#Button_2to3:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next_pressed.png);\n"
                                       "}")
        self.Button_2to3.setText("")
        self.Button_2to3.setObjectName("Button_2to3")
        self.Button_2to3.clicked.connect(self.go_to_third)
        
        
        # Bouton page précédente : 
        self.Button_2to1 = QtWidgets.QPushButton(self.page_2)
        self.Button_2to1.setGeometry(QtCore.QRect(L_WINDOW-2*H_WINDOW//30-3, 0, H_WINDOW//30, H_WINDOW//30))
        self.Button_2to1.setStyleSheet("#Button_2to1{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_2to1:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous_pressed.png);\n"
                                       "}"
                                       "#Button_2to1:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous_pressed.png);\n"
                                       "}")
        self.Button_2to1.setText("")
        self.Button_2to1.setObjectName("Button_2to1")
        self.Button_2to1.clicked.connect(self.go_to_first)

        
       
# =============================================================================
# Page 3 : Pourcentage remplissage/Live video  
# =============================================================================
        self.page_3 = QtWidgets.QWidget()
        self.page_3.setObjectName("page_3")
        self.stackedWidget.addWidget(self.page_3)
        #Fond 3
        self.Background_3 = QtWidgets.QLabel(self.page_3)
        self.Background_3.setGeometry(QtCore.QRect(0, 0, L_WINDOW, H_WINDOW-H_WINDOW//12))
        self.Background_3.setText("")
        self.Background_3.setPixmap(QtGui.QPixmap(".//Projet_Interface/Fond/Plan de travail2.jpg"))
        self.Background_3.setScaledContents(True)
        self.Background_3.setObjectName("Background_3")
        
        #Photo acquise en continue
        self.label_video = QtWidgets.QLabel(self.page_3)
        self.label_video.setGeometry(QtCore.QRect(L_WINDOW//5+L_WINDOW//7-L_WINDOW//105, H_WINDOW//50, L_WINDOW//3+L_WINDOW//60, H_WINDOW//2))
        self.label_video.setText("")
        self.label_video.setPixmap(QtGui.QPixmap("./bleu.png"))
        self.label_video.setObjectName("label_video")
        
        #Image du tapis roulant de profil
        self.tapis_profil = QtWidgets.QLabel(self.page_3)
        self.tapis_profil.setGeometry(QtCore.QRect(L_WINDOW//9+L_WINDOW//60, H_WINDOW//2+H_WINDOW//8, L_WINDOW//2+L_WINDOW//4, H_WINDOW//5))
        self.tapis_profil.setStyleSheet("background-color: None;")
        self.tapis_profil.setText("")
        self.tapis_profil.setPixmap(QtGui.QPixmap(".//Projet_Interface/Convoyeur/convoyeur_profilv2.png"))
        self.tapis_profil.setScaledContents(True)
        self.tapis_profil.setWordWrap(True)
        self.tapis_profil.setObjectName("tapis_profil")
        
        #Image forme/couleur boite 1
        self.forme_1 = QtWidgets.QLabel(self.page_3)
        self.forme_1.setGeometry(QtCore.QRect(L_WINDOW//2+L_WINDOW//8, H_WINDOW-H_WINDOW//5-H_WINDOW//40, L_WINDOW//18, L_WINDOW//18))
        self.forme_1.setStyleSheet("background-color: None;")
        self.forme_1.setText("")
        self.forme_1.setPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/"+str(shape[0]).lower()+".png"))
        self.forme_1.setScaledContents(True)
        self.forme_1.setObjectName("forme_1")
        
        #Image forme/couleur boite 2
        self.forme_2 = QtWidgets.QLabel(self.page_3)
        self.forme_2.setGeometry(QtCore.QRect(L_WINDOW//3+L_WINDOW//7+L_WINDOW//200, H_WINDOW-H_WINDOW//5-H_WINDOW//40, L_WINDOW//18, L_WINDOW//18))
        self.forme_2.setStyleSheet("background-color: None;")
        self.forme_2.setText("")
        self.forme_2.setPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/"+str(shape[1]).lower()+".png"))
        self.forme_2.setScaledContents(True)
        self.forme_2.setObjectName("forme_2")
        
        #Image forme/couleur boite 3
        self.forme_3 = QtWidgets.QLabel(self.page_3)
        self.forme_3.setGeometry(QtCore.QRect(L_WINDOW//3, H_WINDOW-H_WINDOW//5-H_WINDOW//40, L_WINDOW//18, L_WINDOW//18))
        self.forme_3.setStyleSheet("background-color: None;")
        self.forme_3.setText("")
        self.forme_3.setPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/"+str(shape[2]).lower()+".png"))
        self.forme_3.setScaledContents(True)
        self.forme_3.setObjectName("forme_3")
        
        #Bouton stop (marche 0), provoquant l'arrêt de l'appli et des moteurs
        self.Button_stop = QtWidgets.QPushButton(self.page_3)
        self.Button_stop.setGeometry(QtCore.QRect(L_WINDOW-L_WINDOW//10, H_WINDOW-H_WINDOW//4, L_WINDOW//12, L_WINDOW//12))
        self.Button_stop.setStyleSheet("#Button_stop{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_stop//stop.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_stop:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_stop//stop_pressed.png);\n"
                                       "}"
                                       "#Button_stop:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_stop//stop_pressed.png);\n"
                                       "}")
        self.Button_stop.setText("")
        self.Button_stop.setObjectName("Button_stop")
        self.Button_stop.clicked.connect(self.stop)
        
        #Bouton run (marche 0), provoquant l'arrêt de l'appli et des moteurs
        self.Button_run = QtWidgets.QPushButton(self.page_3)
        self.Button_run.setGeometry(QtCore.QRect(L_WINDOW-L_WINDOW//10, H_WINDOW-H_WINDOW//2, L_WINDOW//12, L_WINDOW//12))
        self.Button_run.setStyleSheet("#Button_run{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_stop//run.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_run:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_stop//run_pressed.png);\n"
                                       "}"
                                       "#Button_run:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_stop//run_pressed.png);\n"
                                       "}")
        self.Button_run.setText("")
        self.Button_run.setObjectName("Button_run")
        self.Button_run.clicked.connect(self.start)
        
        #Bouton init (marche 0), provoquant l'arrêt de l'appli et des moteurs
        self.Button_init = QtWidgets.QPushButton(self.page_3)
        self.Button_init.setGeometry(QtCore.QRect(L_WINDOW//30, H_WINDOW-H_WINDOW//4, L_WINDOW//12, L_WINDOW//12))
        self.Button_init.setStyleSheet("#Button_init{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_Init//init.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_init:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_Init//init_pressed.png);\n"
                                       "}"
                                       "#Button_init:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_Init//init_pressed.png);\n"
                                       "}")
        self.Button_init.setText("")
        self.Button_init.setObjectName("Button_init")
        self.Button_init.clicked.connect(self.initServoPressed)

        self.slider = QtWidgets.QSlider(self.page_3)
        self.slider.setGeometry(QtCore.QRect(L_WINDOW//3-L_WINDOW//20, H_WINDOW//8-H_WINDOW//60, L_WINDOW//40, L_WINDOW//6))
        self.slider.setOrientation(QtCore.Qt.Vertical)
        self.slider.setRange(0,255)
        self.slider.setValue(120)#Valeur par défaut du slider
        self.slider.setSingleStep(5)
        self.slider.setObjectName("horizontalSlider")
        self.slider.setStyleSheet("background-color: None;")
    
        self.Background_3.raise_()
        self.tapis_profil.raise_()
        self.label_video.raise_()
        self.forme_1.raise_()
        self.forme_2.raise_()
        self.forme_3.raise_()        
        self.Button_stop.raise_()
        self.Button_run.raise_()
        self.Button_init.raise_()
        self.slider.raise_()


        

        # Bouton page suivante : 
        self.Button_3to1 = QtWidgets.QPushButton(self.page_3)
        self.Button_3to1.setGeometry(QtCore.QRect(L_WINDOW-H_WINDOW//30, 0, H_WINDOW//30, H_WINDOW//30))
        self.Button_3to1.setStyleSheet("#Button_3to1{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_3to1:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next_pressed.png);\n"
                                       "}"
                                       "#Button_3to1:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next_pressed.png);\n"
                                       "}")
        self.Button_3to1.setText("")
        self.Button_3to1.setObjectName("Button_3to1")
        self.Button_3to1.clicked.connect(self.go_to_first)
        
        # Bouton page précédente : 
        self.Button_3to2 = QtWidgets.QPushButton(self.page_3)
        self.Button_3to2.setGeometry(QtCore.QRect(L_WINDOW-2*H_WINDOW//30-3, 0, H_WINDOW//30, H_WINDOW//30))
        self.Button_3to2.setStyleSheet("#Button_3to2{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_3to2:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous_pressed.png);\n"
                                       "}"
                                       "#Button_3to2:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous_pressed.png);\n"
                                       "}")
        self.Button_3to2.setText("")
        self.Button_3to2.setObjectName("Button_3to2")
        self.Button_3to2.clicked.connect(self.return_back)
        
    #Définition des progressBar
        """
        Les progressBar présentent le pourcentage de remplissage des 3 boîtes en 
        continue, jusqu'à 100%, où la capacité maximale est atteinte 
        (boite pleine) provoquant l'arrêt du process.
        
        """
    # =============================================================================
    # Progress bar 1, pourcentage
    # =============================================================================
        #Frame_Fond (encapsulation dedans, pour bouger l'ensemble)
        self.circularProgressBarBase1 = QtWidgets.QFrame(self.page_3)
        self.circularProgressBarBase1.setGeometry(QtCore.QRect(L_WINDOW//2+L_WINDOW//9, H_WINDOW//2+H_WINDOW//30, L_WINDOW//5, L_WINDOW//5))
        self.circularProgressBarBase1.setStyleSheet("background : None")
        self.circularProgressBarBase1.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularProgressBarBase1.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularProgressBarBase1.setObjectName("circularProgressBarBase1")
        
        #Fond transparent derrière
        self.circularBg1 = QtWidgets.QFrame(self.circularProgressBarBase1)
        self.circularBg1.setGeometry(QtCore.QRect(L_WINDOW//144, L_WINDOW//144, L_WINDOW//14, L_WINDOW//14))
        self.circularBg1.setStyleSheet("QFrame{\n"
                                      "    border-radius : "+str(L_WINDOW//28)+"px;\n"
                                      "    background-color: rgba(77, 77, 127, 120);\n"
                                      "\n"
                                      "}")
        self.circularBg1.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularBg1.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularBg1.setObjectName("circularBg1")
        
        #Cercle chromatique qui va tourner selon le pourcentage
        self.circularProgress1 = QtWidgets.QFrame(self.circularProgressBarBase1)
        self.circularProgress1.setGeometry(QtCore.QRect(L_WINDOW//144, L_WINDOW//144, L_WINDOW//14, L_WINDOW//14))
        self.circularProgress1.setStyleSheet("QFrame{\n"
                                            "    border-radius :"+str(L_WINDOW//28)+"px;\n"
                                            "    background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:0.749 rgba(255, 0, 127, 0), stop:0.750 rgba(85, 170, 255, 255));\n"
                                            "    \n"
                                            "}")
        #stop définit le pourcentage de rotation
        #si stop1=0.749, stop2=0.750, définit 1-75%, donc 25% de remplissage
        #cette valeur est changée à période régulière par SignalContinu
        #qui recréé cette StyleSheet (voir plus loin)
        
        self.circularProgress1.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularProgress1.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularProgress1.setObjectName("circularProgress1")
        
        #Fond violet du devant où le texte est placé
        self.container1 = QtWidgets.QFrame(self.circularProgressBarBase1)
        self.container1.setGeometry(QtCore.QRect(L_WINDOW//85, L_WINDOW//88, L_WINDOW//16, L_WINDOW//16))
        self.container1.setStyleSheet("QFrame{\n"
                                     "    border-radius : +"+str(L_WINDOW//32)+"px;\n"
                                     "    background-color: rgb(77, 77, 127);\n"
                                     "}")
        self.container1.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.container1.setFrameShadow(QtWidgets.QFrame.Raised)
        self.container1.setObjectName("container1")
        #Grouper le texte en un bloc
        self.widget1 = QtWidgets.QWidget(self.container1)
        self.widget1.setGeometry(QtCore.QRect(L_WINDOW//80, L_WINDOW//140, L_WINDOW//27, L_WINDOW//22))
        self.widget1.setObjectName("widget1")
        
        
        self.formLayout1 = QtWidgets.QFormLayout(self.widget1)
        self.formLayout1.setContentsMargins(0, 0, 0, 0)
        self.formLayout1.setObjectName("formLayout1")
      
        #Texte du pourcentage
        self.label_percent1 = QtWidgets.QLabel(self.widget1)
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(3)
   
        self.label_percent1.setFont(font)
        self.label_percent1.setStyleSheet("background-color : none; color: #FFFFFF;")
        self.label_percent1.setAlignment(QtCore.Qt.AlignRight)
        self.label_percent1.setObjectName("label_percent1")
        
        
        #Texte du numéro de la boîte
        self.label_box1 = QtWidgets.QLabel(self.widget1)
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(L_WINDOW//384)
        self.label_box1.setFont(font)
        self.label_box1.setStyleSheet("background-color : none; color: #FFFFFF;")
        self.label_box1.setAlignment(QtCore.Qt.AlignCenter)
        self.label_box1.setObjectName("label_box1")
        
        self.formLayout1.setWidget(1, QtWidgets.QFormLayout.SpanningRole, self.label_percent1)
        self.formLayout1.setWidget(0, QtWidgets.QFormLayout.SpanningRole, self.label_box1)
        
            
        self.circularProgressBarBase1.raise_()

      
    # =============================================================================
    # Progress bar 2, pourcentage
    # =============================================================================
        self.circularProgressBarBase2 = QtWidgets.QFrame(self.page_3)
        self.circularProgressBarBase2.setGeometry(QtCore.QRect(L_WINDOW//2-L_WINDOW//30, H_WINDOW//2+H_WINDOW//30, L_WINDOW//5, L_WINDOW//5))
        self.circularProgressBarBase2.setStyleSheet("background : None")
        self.circularProgressBarBase2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularProgressBarBase2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularProgressBarBase2.setObjectName("circularProgressBarBase2")
        
        
        self.circularBg2 = QtWidgets.QFrame(self.circularProgressBarBase2)
        self.circularBg2.setGeometry(QtCore.QRect(L_WINDOW//144, L_WINDOW//144, L_WINDOW//14, L_WINDOW//14))
        self.circularBg2.setStyleSheet("QFrame{\n"
                                      "    border-radius : "+str(L_WINDOW//28)+"px;\n"
                                      "    background-color: rgba(77, 77, 127, 120);\n"
                                      "\n"
                                      "}")
        self.circularBg2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularBg2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularBg2.setObjectName("circularBg2")
        
        self.circularProgress2 = QtWidgets.QFrame(self.circularProgressBarBase2)
        self.circularProgress2.setGeometry(QtCore.QRect(L_WINDOW//144, L_WINDOW//144, L_WINDOW//14, L_WINDOW//14))
        self.circularProgress2.setStyleSheet("QFrame{\n"
                                            "    border-radius :"+str(L_WINDOW//28)+"px;\n"
                                            "    background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:0.749 rgba(255, 0, 127, 0), stop:0.750 rgba(85, 170, 255, 255));\n"
                                            "    \n"
                                            "}")
        self.circularProgress2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularProgress2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularProgress2.setObjectName("circularProgress2")
        
        self.container2 = QtWidgets.QFrame(self.circularProgressBarBase2)
        self.container2.setGeometry(QtCore.QRect(L_WINDOW//85, L_WINDOW//88, L_WINDOW//16, L_WINDOW//16))
        self.container2.setStyleSheet("QFrame{\n"
                                     "    border-radius : +"+str(L_WINDOW//32)+"px;\n"
                                     "    background-color: rgb(77, 77, 127);\n"
                                     "}")
        self.container2.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.container2.setFrameShadow(QtWidgets.QFrame.Raised)
        self.container2.setObjectName("container2")
        self.widget2 = QtWidgets.QWidget(self.container2)
        self.widget2.setGeometry(QtCore.QRect(L_WINDOW//80, L_WINDOW//140, L_WINDOW//27, L_WINDOW//22))
        self.widget2.setObjectName("widget2")
        
        
        self.formLayout2 = QtWidgets.QFormLayout(self.widget2)
        self.formLayout2.setContentsMargins(0, 0, 0, 0)
        self.formLayout2.setObjectName("formLayout2")
      
        self.label_percent2 = QtWidgets.QLabel(self.widget2)
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(3)
        #Pourcentage
        self.label_percent2.setFont(font)
        self.label_percent2.setStyleSheet("background-color : none; color: #FFFFFF;")
        self.label_percent2.setAlignment(QtCore.Qt.AlignRight)
        self.label_percent2.setObjectName("label_percent2")
        
        self.label_box2 = QtWidgets.QLabel(self.widget2)
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(L_WINDOW//384)
        self.label_box2.setFont(font)
        self.label_box2.setStyleSheet("background-color : none; color: #FFFFFF;")
        self.label_box2.setAlignment(QtCore.Qt.AlignCenter)
        self.label_box2.setObjectName("label_box2")
        
        self.formLayout2.setWidget(1, QtWidgets.QFormLayout.SpanningRole, self.label_percent2)
        self.formLayout2.setWidget(0, QtWidgets.QFormLayout.SpanningRole, self.label_box2)
        
            
        self.circularProgressBarBase2.raise_()

    # =============================================================================
    # Progress bar 3, pourcentage
    # =============================================================================
        self.circularProgressBarBase3 = QtWidgets.QFrame(self.page_3)
        self.circularProgressBarBase3.setGeometry(QtCore.QRect(L_WINDOW//3-L_WINDOW//60, H_WINDOW//2+H_WINDOW//30, L_WINDOW//5, L_WINDOW//5))
        self.circularProgressBarBase3.setStyleSheet("background : None")
        self.circularProgressBarBase3.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularProgressBarBase3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularProgressBarBase3.setObjectName("circularProgressBarBase3")
        
        
        self.circularBg3 = QtWidgets.QFrame(self.circularProgressBarBase3)
        self.circularBg3.setGeometry(QtCore.QRect(L_WINDOW//144, L_WINDOW//144, L_WINDOW//14, L_WINDOW//14))
        self.circularBg3.setStyleSheet("QFrame{\n"
                                      "    border-radius : "+str(L_WINDOW//28)+"px;\n"
                                      "    background-color: rgba(77, 77, 127, 120);\n"
                                      "\n"
                                      "}")
        self.circularBg3.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularBg3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularBg3.setObjectName("circularBg3")
        
        self.circularProgress3 = QtWidgets.QFrame(self.circularProgressBarBase3)
        self.circularProgress3.setGeometry(QtCore.QRect(L_WINDOW//144, L_WINDOW//144, L_WINDOW//14, L_WINDOW//14))
        self.circularProgress3.setStyleSheet("QFrame{\n"
                                            "    border-radius :"+str(L_WINDOW//28)+"px;\n"
                                            "    background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:0.749 rgba(255, 0, 127, 0), stop:0.750 rgba(85, 170, 255, 255));\n"
                                            "    \n"
                                            "}")
        self.circularProgress3.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.circularProgress3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.circularProgress3.setObjectName("circularProgress3")
        
        self.container3 = QtWidgets.QFrame(self.circularProgressBarBase3)
        self.container3.setGeometry(QtCore.QRect(L_WINDOW//85, L_WINDOW//88, L_WINDOW//16, L_WINDOW//16))
        self.container3.setStyleSheet("QFrame{\n"
                                     "    border-radius : +"+str(L_WINDOW//32)+"px;\n"
                                     "    background-color: rgb(77, 77, 127);\n"
                                     "}")
        self.container3.setFrameShape(QtWidgets.QFrame.NoFrame)
        self.container3.setFrameShadow(QtWidgets.QFrame.Raised)
        self.container3.setObjectName("container3")
        self.widget3 = QtWidgets.QWidget(self.container3)
        self.widget3.setGeometry(QtCore.QRect(L_WINDOW//80, L_WINDOW//140, L_WINDOW//27, L_WINDOW//22))
        self.widget3.setObjectName("widget3")
        
        
        self.formLayout3 = QtWidgets.QFormLayout(self.widget3)
        self.formLayout3.setContentsMargins(0, 0, 0, 0)
        self.formLayout3.setObjectName("formLayout1")
      
        self.label_percent3 = QtWidgets.QLabel(self.widget3)
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(3)
        #Pourcentage
        self.label_percent3.setFont(font)
        self.label_percent3.setStyleSheet("background-color : none; color: #FFFFFF;")
        self.label_percent3.setAlignment(QtCore.Qt.AlignRight)
        self.label_percent3.setObjectName("label_percent3")
        
        self.label_box3 = QtWidgets.QLabel(self.widget3)
        font = QtGui.QFont()
        font.setFamily("Segoe UI")
        font.setPointSize(L_WINDOW//384)
        self.label_box3.setFont(font)
        self.label_box3.setStyleSheet("background-color : none; color: #FFFFFF;")
        self.label_box3.setAlignment(QtCore.Qt.AlignCenter)
        self.label_box3.setObjectName("label_box3")
        
        self.formLayout3.setWidget(1, QtWidgets.QFormLayout.SpanningRole, self.label_percent3)
        self.formLayout3.setWidget(0, QtWidgets.QFormLayout.SpanningRole, self.label_box3)
        
            
        self.circularProgressBarBase3.raise_()
    
        
# =============================================================================
# Page 4 : Formes
# =============================================================================
        
        self.page_4 = QtWidgets.QWidget()
        self.page_4.setObjectName("page_4")
        self.stackedWidget.addWidget(self.page_4)
        #Fond 4
        self.Background_4 = QtWidgets.QLabel(self.page_4)
        self.Background_4.setGeometry(QtCore.QRect(0, 0, L_WINDOW, H_WINDOW-H_WINDOW//12))
        self.Background_4.setText("")
        self.Background_4.setPixmap(QtGui.QPixmap(".//Projet_Interface/Fond/Plan de travail2.jpg"))
        self.Background_4.setScaledContents(True)
        self.Background_4.setObjectName("Background_4")
        
        
        #Image du convoyeur de haut
        self.img_convoyeur_4 = QtWidgets.QLabel(self.page_4)
        self.img_convoyeur_4.setGeometry(QtCore.QRect(-L_WINDOW//24, H_WINDOW//6, L_WINDOW+L_WINDOW//8, 5*(H_WINDOW//8)))
        self.img_convoyeur_4.setStyleSheet("background-color: transparent;\n"
                                           "background : none;\n"
                                           "\n"
                                           "")
        self.img_convoyeur_4.setText("")
        self.img_convoyeur_4.setPixmap(QtGui.QPixmap(".//Projet_Interface/Convoyeur/convoyeur.png"))
        self.img_convoyeur_4.setScaledContents(True)
        self.img_convoyeur_4.setObjectName("img_convoyeur_4")
        
        #Boite 1      
        self.img_box4_1 = QtWidgets.QLabel(self.page_4)
        self.img_box4_1.setGeometry(QtCore.QRect(2*(L_WINDOW//3), H_WINDOW//48, L_WINDOW//9, H_WINDOW//4+H_WINDOW//23))
        self.img_box4_1.setStyleSheet("background-color: transparent;\n"
                                     "background : none;\n"
                                     "\n"
                                     "\n"
                                     "")
        self.img_box4_1.setText("")
        self.img_box4_1.setPixmap(QtGui.QPixmap(".//Projet_Interface/Boite/boite.png"))
        self.img_box4_1.setScaledContents(True)
        self.img_box4_1.setObjectName("img_box4_1")
        
              
        
        #Boite 2
        self.img_box4_2 = QtWidgets.QLabel(self.page_4)
        self.img_box4_2.setGeometry(QtCore.QRect(L_WINDOW//2-L_WINDOW//20, H_WINDOW//2+H_WINDOW//11, L_WINDOW//9, H_WINDOW//4+H_WINDOW//23))
        self.img_box4_2.setStyleSheet("background-color: transparent;\n"
                                      "background : none;\n"
                                      "\n"
                                      "\n"
                                      "")
        self.img_box4_2.setText("")
        self.img_box4_2.setPixmap(QtGui.QPixmap(".//Projet_Interface/Boite/boite.png"))
        self.img_box4_2.setScaledContents(True)
        self.img_box4_2.setObjectName("img_box4_2")
        
        
        
        #Boite 3
        self.img_box4_3 = QtWidgets.QLabel(self.page_4)
        self.img_box4_3.setGeometry(QtCore.QRect(L_WINDOW//3-L_WINDOW//10, H_WINDOW//48, L_WINDOW//9, H_WINDOW//4+H_WINDOW//23))
        self.img_box4_3.setStyleSheet("background-color: transparent;\n"
                                      "background : none;\n"
                                      "\n"
                                      "\n"
                                      "")
        self.img_box4_3.setText("")
        self.img_box4_3.setPixmap(QtGui.QPixmap(".//Projet_Interface/Boite/boite.png"))
        self.img_box4_3.setScaledContents(True)
        self.img_box4_3.setObjectName("img_box4_3")
        
        
        #Definition de la combobox de la boite 1 pour choisir des formes
        self.comboBox4_1 = QtWidgets.QComboBox(self.page_4)
        self.comboBox4_1.setGeometry(QtCore.QRect(L_WINDOW//2+L_WINDOW//40, H_WINDOW//53, L_WINDOW//7, H_WINDOW//22))
        self.comboBox4_1.setStyleSheet("background-color: rgb(30, 24, 84);\n"
                                       "font: 8pt \"Calibri\";\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        #Associations d'images à chaque icon du combobox        
        self.comboBox4_1.setObjectName("comboBox4_1")
        icon_shape = QtGui.QIcon()
        icon_shape.addPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/cercle.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox4_1.addItem(icon_shape, "")
        icon_shape1 = QtGui.QIcon()
        icon_shape1.addPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/carre.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox4_1.addItem(icon_shape1, "")
        icon_shape2 = QtGui.QIcon()
        icon_shape2.addPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/rectangle.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox4_1.addItem(icon_shape2, "")
        icon_shape3 = QtGui.QIcon()
        icon_shape3.addPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/triangle.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox4_1.addItem(icon_shape3, "")
        icon_shape4 = QtGui.QIcon()
        icon_shape4.addPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/pentagone.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox4_1.addItem(icon_shape4, "")
        icon_shape5 = QtGui.QIcon()
        icon_shape5.addPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/hexagone.png"), QtGui.QIcon.Normal, QtGui.QIcon.Off)
        self.comboBox4_1.addItem(icon_shape5, "")
        
        
        #Definition de la combobox de la boite 2 pour choisir des formes
        self.comboBox4_2 = QtWidgets.QComboBox(self.page_4)
        self.comboBox4_2.setGeometry(QtCore.QRect(L_WINDOW//2-L_WINDOW//5+L_WINDOW//120, H_WINDOW//3+H_WINDOW//2, L_WINDOW//7, H_WINDOW//22))
        self.comboBox4_2.setStyleSheet("background-color: rgb(30, 24, 84);\n"
                                       "font: 8pt \"Calibri\";\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        self.comboBox4_2.setObjectName("comboBox4_2")
        self.comboBox4_2.addItem(icon_shape1, "")
        self.comboBox4_2.addItem(icon_shape, "")
        self.comboBox4_2.addItem(icon_shape2, "")
        self.comboBox4_2.addItem(icon_shape3, "")
        self.comboBox4_2.addItem(icon_shape4, "")
        self.comboBox4_2.addItem(icon_shape5, "")

        
        
        #Definition de la combobox de la boite 3 pour choisir des formes
        self.comboBox4_3 = QtWidgets.QComboBox(self.page_4)
        self.comboBox4_3.setGeometry(QtCore.QRect(L_WINDOW//11, H_WINDOW//53, L_WINDOW//7, H_WINDOW//22))
        self.comboBox4_3.setStyleSheet("background-color: rgb(30, 24, 84);\n"
                                       "font: 8pt \"Calibri\";\n"
                                       "color: rgb(255, 255, 255);\n"
                                       "border-radius: 5px\n"
                                       "")
        self.comboBox4_3.setObjectName("comboBox4_3")
        self.comboBox4_3.addItem(icon_shape5, "")
        self.comboBox4_3.addItem(icon_shape, "")
        self.comboBox4_3.addItem(icon_shape1, "")
        self.comboBox4_3.addItem(icon_shape2, "")
        self.comboBox4_3.addItem(icon_shape3, "")
        self.comboBox4_3.addItem(icon_shape4, "")
       

        #Bouton start permettant de démarrer les moteurs (marche 1), Initialiser les pourcentages à zéros (boîtes vides)
        self.Button_start_4 = QtWidgets.QPushButton(self.page_4)
        self.Button_start_4.setGeometry(QtCore.QRect(L_WINDOW-L_WINDOW//10, H_WINDOW-H_WINDOW//4, L_WINDOW//12, L_WINDOW//12))
        self.Button_start_4.setStyleSheet("#Button_start_4{\n"
                                          "background-color: transparent;\n"
                                          "border-image: url(.//Projet_interface//Bouton_start//start2.png);\n"
                                          "background : none;\n"
                                          "border : none;\n"
                                          "background-repeat : none;\n"
                                          "}\n"
                                          "#Button_start_4:pressed{\n"
                                          "border-image: url(.//Projet_interface//Bouton_start//start2_pressed.png);\n"
                                          "}"
                                          "#Button_start_4:hover{\n"
                                          "border-image: url(.//Projet_interface//Bouton_start//start2_pressed.png);\n"
                                          "}")
        self.Button_start_4.setText("")
        self.Button_start_4.setObjectName("Button_start_4")
        self.Button_start_4.clicked.connect(self.meth_button_start)
        
        # Bouton page suivante : 
        self.Button_4to3 = QtWidgets.QPushButton(self.page_4)
        self.Button_4to3.setGeometry(QtCore.QRect(L_WINDOW-H_WINDOW//30, 0, H_WINDOW//30, H_WINDOW//30))
        self.Button_4to3.setStyleSheet("#Button_4to3{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_4to3:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next_pressed.png);\n"
                                       "}"
                                       "#Button_4to3:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//next_pressed.png);\n"
                                       "}")
        self.Button_4to3.setText("")
        self.Button_4to3.setObjectName("Button_4to3")
        self.Button_4to3.clicked.connect(self.go_to_third)
        
        
        # Bouton page précédente : 
        self.Button_4to1 = QtWidgets.QPushButton(self.page_4)
        self.Button_4to1.setGeometry(QtCore.QRect(L_WINDOW-2*H_WINDOW//30-3, 0, H_WINDOW//30, H_WINDOW//30))
        self.Button_4to1.setStyleSheet("#Button_4to1{\n"
                                       "background-color: transparent;\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous.png);\n"
                                       "background : none;\n"
                                       "border : none;\n"
                                       "background-repeat : none;\n"
                                       "}\n"
                                       "#Button_4to1:pressed{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous_pressed.png);\n"
                                       "}"
                                       "#Button_4to1:hover{\n"
                                       "border-image: url(.//Projet_interface//Bouton_suivant//previous_pressed.png);\n"
                                       "}")
        self.Button_4to1.setText("")
        self.Button_4to1.setObjectName("Button_4to1")
        self.Button_4to1.clicked.connect(self.go_to_first)

        
        self.horizontalLayout_2.addWidget(self.frame)
        self.verticalLayout.addWidget(self.Content)
        MainWindow.setCentralWidget(self.centralwidget)
        
        
        
# =============================================================================
#   PAGE COURANTE AU LANCEMENT DE L'APPLI
# =============================================================================
        
        # Page actuelle à l'initialisation
        self.stackedWidget.setCurrentIndex(0)
        
        
        # Redéfinir le texte
        self.retranslateUi(MainWindow)
        
        QtCore.QMetaObject.connectSlotsByName(MainWindow)
        
 
    def retranslateUi(self, MainWindow):  # designer
        """Redéfinir le texte des boutons, combobox...
        
        """
        _translate = QtCore.QCoreApplication.translate
        MainWindow.setWindowTitle(_translate("MainWindow", "ViewSort Application - commande du projet vision industrielle"))
        self.Button_valider.setText(_translate("MainWindow", "VALIDER"))
        self.label_vitesse.setText(_translate("MainWindow", "Vitesse convoyeur"))
        self.label_taille.setText(_translate("MainWindow", "Taille detection max"))
        
        
        self.comboBox2_1.setItemText(0, _translate("MainWindow", "ROUGE"))
        self.comboBox2_1.setItemText(1, _translate("MainWindow", "ORANGE"))
        self.comboBox2_1.setItemText(2, _translate("MainWindow", "JAUNE"))
        self.comboBox2_1.setItemText(3, _translate("MainWindow", "VERT_CLAIR"))
        self.comboBox2_1.setItemText(4, _translate("MainWindow", "VERT_FONCE"))
        self.comboBox2_1.setItemText(5, _translate("MainWindow", "BLEU_CLAIR"))
        self.comboBox2_1.setItemText(6, _translate("MainWindow", "BLEU_FONCE"))
        self.comboBox2_1.setItemText(7, _translate("MainWindow", "VIOLET"))
        self.comboBox2_1.setItemText(8, _translate("MainWindow", "ROSE"))
        self.comboBox2_1.setItemText(9, _translate("MainWindow", "MARRON"))
        
        self.comboBox2_2.setItemText(0, _translate("MainWindow", "VERT_FONCE"))
        self.comboBox2_2.setItemText(1, _translate("MainWindow", "ROUGE"))
        self.comboBox2_2.setItemText(2, _translate("MainWindow", "ORANGE"))
        self.comboBox2_2.setItemText(3, _translate("MainWindow", "JAUNE"))
        self.comboBox2_2.setItemText(4, _translate("MainWindow", "VERT_CLAIR"))
        self.comboBox2_2.setItemText(5, _translate("MainWindow", "BLEU_CLAIR"))
        self.comboBox2_2.setItemText(6, _translate("MainWindow", "BLEU_FONCE"))
        self.comboBox2_2.setItemText(7, _translate("MainWindow", "VIOLET"))
        self.comboBox2_2.setItemText(8, _translate("MainWindow", "ROSE"))
        self.comboBox2_2.setItemText(9, _translate("MainWindow", "MARRON"))
        
        self.comboBox2_3.setItemText(0, _translate("MainWindow", "BLEU_FONCE"))
        self.comboBox2_3.setItemText(1, _translate("MainWindow", "ROUGE"))
        self.comboBox2_3.setItemText(2, _translate("MainWindow", "ORANGE"))
        self.comboBox2_3.setItemText(3, _translate("MainWindow", "JAUNE"))
        self.comboBox2_3.setItemText(4, _translate("MainWindow", "VERT_CLAIR"))
        self.comboBox2_3.setItemText(5, _translate("MainWindow", "VERT_FONCE"))
        self.comboBox2_3.setItemText(6, _translate("MainWindow", "BLEU_CLAIR"))
        self.comboBox2_3.setItemText(7, _translate("MainWindow", "VIOLET"))
        self.comboBox2_3.setItemText(8, _translate("MainWindow", "ROSE"))
        self.comboBox2_3.setItemText(9, _translate("MainWindow", "MARRON"))
        
                
        self.comboBox4_1.setItemText(0, _translate("MainWindow", "CERCLE"))
        self.comboBox4_1.setItemText(1, _translate("MainWindow", "CARRE"))
        self.comboBox4_1.setItemText(2, _translate("MainWindow", "RECTANGLE"))
        self.comboBox4_1.setItemText(3, _translate("MainWindow", "TRIANGLE"))
        self.comboBox4_1.setItemText(4, _translate("MainWindow", "PENTAGONE"))
        self.comboBox4_1.setItemText(5, _translate("MainWindow", "HEXAGONE"))
          
        self.comboBox4_2.setItemText(0, _translate("MainWindow", "CARRE"))
        self.comboBox4_2.setItemText(1, _translate("MainWindow", "CERCLE"))
        self.comboBox4_2.setItemText(2, _translate("MainWindow", "RECTANGLE"))
        self.comboBox4_2.setItemText(3, _translate("MainWindow", "TRIANGLE"))
        self.comboBox4_2.setItemText(4, _translate("MainWindow", "PENTAGONE"))
        self.comboBox4_2.setItemText(5, _translate("MainWindow", "HEXAGONE"))

        self.comboBox4_3.setItemText(0, _translate("MainWindow", "HEXAGONE"))
        self.comboBox4_3.setItemText(1, _translate("MainWindow", "CERCLE"))
        self.comboBox4_3.setItemText(2, _translate("MainWindow", "CARRE"))
        self.comboBox4_3.setItemText(3, _translate("MainWindow", "RECTANGLE"))
        self.comboBox4_3.setItemText(4, _translate("MainWindow", "TRIANGLE"))
        self.comboBox4_3.setItemText(5, _translate("MainWindow", "PENTAGONE"))
        
        
    def set_pourcentage(self, pourcentage_box):
        """Appelle la fonction progressBarValue(n°boîte, %) pour mettre à jour 
        le pourcentage de remplissage et changer graphiquement la roue 
        ciruclaire de la progressBar.

        Parameters
        ----------
        pourcentage_box : list de taille 3 pourcentages (int de 0 à 100)
            Récupère le pourcentage de remplissage pour chaque boîte

        """
        _translate = QtCore.QCoreApplication.translate
        
        for i in range (0,2):
            #Si la boîte est pleine, graphiquement, on bloque à 100% rouge
            if pourcentage_box[i]>99:
                pourcentage_box[i]=100
                self.progressBarValue(i+1, 100)
                print("La capacité maximale est atteinte")

        # Changement graphique de la progressBar_circulaire selon le %
        self.progressBarValue(1, pourcentage_box[0])
        # Fonts pourcentages et écriture du pourcentage boîte 1
        self.label_percent1.setText(_translate("MainWindow", "<p><span style=\" font-size:"+str(L_WINDOW//160)+"pt;\">"+str(pourcentage_box[0])+"</span><span style=\" font-size:"+str(L_WINDOW//240)+"pt; vertical-align:super;\">%</span></p>"))
        # Fonts boîte 1
        self.label_box1.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#9b9bff;\">BOX</span> 1</p></body></html>"))

     
        self.progressBarValue(2, pourcentage_box[1])
        self.label_percent2.setText(_translate("MainWindow", "<p><span style=\" font-size:"+str(L_WINDOW//160)+"pt;\">"+str(pourcentage_box[1])+"</span><span style=\" font-size:"+str(L_WINDOW//240)+"pt; vertical-align:super;\">%</span></p>"))
        self.label_box2.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#9b9bff;\">BOX</span> 2</p></body></html>"))

        
        self.progressBarValue(3, pourcentage_box[2])
        self.label_percent3.setText(_translate("MainWindow", "<p><span style=\" font-size:"+str(L_WINDOW//160)+"pt;\">"+str(pourcentage_box[2])+"</span><span style=\" font-size:"+str(L_WINDOW//240)+"pt; vertical-align:super;\">%</span></p>"))
        self.label_box3.setText(_translate("MainWindow", "<html><head/><body><p><span style=\" font-weight:600; color:#9b9bff;\">BOX</span> 3</p></body></html>"))
  
        
             
            

# =============================================================================
# Changer de page
# =============================================================================

    def go_to_first(self):
        """Se déplacer à la page 1 du stackedWidget

        """
        self.stackedWidget.setCurrentIndex(0)
    
    def go_to_second(self):
        """Se déplacer à la page 2 du stackedWidget

        """
        self.stackedWidget.setCurrentIndex(1)
    
    def go_to_third(self):
        """Se déplacer à la page 3 du stackedWidget

        """
        self.stackedWidget.setCurrentIndex(2)
    
    def go_to_fourth(self):
        """Se déplacer à la page 4 du stackedWidget

        """
        self.stackedWidget.setCurrentIndex(3) 
       
    
# =============================================================================
# Choix couleur-forme
# =============================================================================
        
    def choice_color(self):
        """Le booléen global choice est à 1, si on fait le choix de détection de couleur

        """
        global choice
        choice = True
        self.go_to_second()
        
        config.remplissage_color = {'ROUGE': 0, 'ORANGE': 0, 'JAUNE': 0, 'VERT_CLAIR': 0, 
                    'VERT_FONCE' : 0, 'BLEU_CLAIR': 0, 'BLEU_FONCE': 0,
                     'VIOLET': 0, "ROSE" : 0, "MARRON" : 0, "INDEFINI" : 0}  
        config.remplissage_shape = {'TRIANGLE': 0, 'CARRE': 0, 'RECTANGLE': 0,
                   'PENTAGONE': 0, 'HEXAGONE' : 0, 'ETOILE': 0, 'CERCLE': 0} 
        
    def choice_shape(self):
        """Le booléen global choice est à 0, si on fait le choix de détection de formes

        """
        global choice
        choice = False
        self.go_to_fourth()
        
        config.remplissage_color = {'ROUGE': 0, 'ORANGE': 0, 'JAUNE': 0, 'VERT_CLAIR': 0, 
                    'VERT_FONCE' : 0, 'BLEU_CLAIR': 0, 'BLEU_FONCE': 0,
                     'VIOLET': 0, "ROSE" : 0, "MARRON" : 0, "INDEFINI" : 0}  
        config.remplissage_shape = {'TRIANGLE': 0, 'CARRE': 0, 'RECTANGLE': 0,
                   'PENTAGONE': 0, 'HEXAGONE' : 0, 'ETOILE': 0, 'CERCLE': 0} 
        
    def stop(self):
        """
        Arrête le process : pourcentage stop, moteurs off grâce à marche = 0

        """
        global marche
        print('stop')
        marche = 0
        ser.write(bytes('s', 'utf-8'))
        print("Moteurs à l'arrêt")
      
    def start(self):
        """
        Démarre le process : moteurs on grâce à marche = 1

        """
        print('run')
        global marche, servo_retour
        marche = 1
        ser.write(bytes('r', 'utf-8'))
        servo_retour = 0 #Les servo ne sont plus forcés en position minimale
        print("Moteurs en route")
        
    def meth_button_start(self):
        """Démarre le process de détection :
            
            Moteurs "ON" grâce à marche=1
            
            Se placer à la page de suivi du remplissage, affichage des bonnes couleurs/formes choisies
            
            Pourcentage run à partir de 0%, début du timer continu
            
        """
        global pourcentage_box

        global choice
        self.start( )#Démarre les moteurs
        self.go_to_third() #Se déplace à la page 3 : suivi du remplissage    

        if choice==True:  
            #Si le choix était couleur, on place les couleurs choisies respectives aux boîtes
            global color
            color1 = self.comboBox2_1.currentText()
            color2 = self.comboBox2_2.currentText()
            color3 = self.comboBox2_3.currentText()
            print(f"box 1 : {color1}, box 2 : {color2}, box 3 : {color3}")
            color = [color1, color2, color3]
           
            self.forme_1.setPixmap(QtGui.QPixmap(".//Projet_Interface/Palette/"+str(color[0]).lower()+".png"))
            self.forme_2.setPixmap(QtGui.QPixmap(".//Projet_Interface/Palette/"+str(color[1]).lower()+".png"))
            self.forme_3.setPixmap(QtGui.QPixmap(".//Projet_Interface/Palette/"+str(color[2]).lower()+".png"))

        else :
            #Si le choix était forme, on place les formes choisies respectives aux boîtes
            global shape
            shape1 = self.comboBox4_1.currentText()
            shape2 = self.comboBox4_2.currentText()
            shape3 = self.comboBox4_3.currentText()
            print(f"box 1 : {shape1}, box 2 : {shape2}, box 3 : {shape3}")
            shape = [shape1, shape2, shape3]
            
            self.forme_1.setPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/"+str(shape[0]).lower()+".png"))
            self.forme_2.setPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/"+str(shape[1]).lower()+".png"))
            self.forme_3.setPixmap(QtGui.QPixmap(".//Projet_Interface/Formes/"+str(shape[2]).lower()+".png"))

        # Initialisation des pourcentages à 0%
        pourcentage_box = [0, 0, 0]
        #Remplie le pourcentage initialiser à 0 sur les roues chromatiques de %
        self.set_pourcentage(pourcentage_box)

 

            
    def return_back(self):
        """Permet de la page 3 commune au choix couleur/forme de retourner à la
        page 2(couleur) ou 4(forme)

        """
        global choice
        if choice == True:
            self.go_to_second()

        else :
            self.go_to_fourth()
            
    def valider(self):
        """Valider les paramètres dans la barre du haut

        """
        global vitesse, taille_max
        vitesse = self.spin_vitesse.value()
        taille_max = self.spin_taille.value()
       
        print(f"vitesse {vitesse}, taille max {taille_max}")

    def progressBarValue(self, num_box, value):
        """Méthode permettant de changer l'icône graphique de pourcentage qui défile en
        continue selon le remplissage des boîtes
    
        Parameters
        ----------
        num_box : int (1, 2, 3)
            numero de boite pour changer la progressBar
        value : int (0 à 100)
            % de remplissage associée à la boîte choisie

       
        """    
        
        #Association des couleurs aux valeurs RGBalpha
        global color
        global choice
        color_rgba=(0,0,0, 255)
        if color[num_box-1]=="ROUGE":
            color_rgba = "255"+','+"0"+','+"0"+','+"255"
        elif color[num_box-1]== "ORANGE":
            color_rgba = "252"+','+"136"+','+"0"+','+"255"
        elif color[num_box-1]== "JAUNE":
            color_rgba = "236"+','+"218"+','+"19"+','+"255"
        elif color[num_box-1]== "VERT_CLAIR":
            color_rgba = "132"+','+"211"+','+"89"+','+"255"
        elif color[num_box-1]== "VERT_FONCE":
            color_rgba = "54"+','+"129"+','+"35"+','+"255"
        elif color[num_box-1]== "BLEU_CLAIR":
            color_rgba = "89"+','+"187"+','+"211"+','+"255"
        elif color[num_box-1]== "BLEU_FONCE":
            color_rgba = "48"+','+"116"+','+"226"+','+"255"
        elif color[num_box-1]== "VIOLET":
            color_rgba = "120"+','+"9"+','+"184"+','+"255"
        elif color[num_box-1]== "ROSE":
            color_rgba = "237"+','+"122"+','+"225"+','+"255"
        elif color[num_box-1]== "MARRON":
            color_rgba = "84"+','+"59"+','+"67"+','+"255"
        else: 
            color_rgba = "85"+','+"170"+','+"255"+','+"255"
              
                     
    
        if value > 90 and value < 97: #Boites presque pleines : orange
            styleSheet = """QFrame{\n
                                border-radius : """+str(L_WINDOW//28)+"""px;\n
                                background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba(252, 136, 0, 255));\n
                         }"""
    
    
        elif value>=97: # Boites pleines : rouge
            styleSheet = """QFrame{\n
                                border-radius : """+str(L_WINDOW//28)+"""px;\n
                                background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba(255, 0, 0, 255));\n
                         }"""
    
        # Jauge de couleurs selon la couleur choisie à détecter
        elif (num_box==1 and choice==True):
            # Boites 1 : personalisée
            styleSheet = """QFrame{\n
                                border-radius : """+str(L_WINDOW//28)+"""px;\n
                                background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba("""+color_rgba+"""));\n
                         }"""
        elif (num_box==2 and choice==True):
            # Boites 2 : personalisée
            styleSheet = """QFrame{\n
                                border-radius : """+str(L_WINDOW//28)+"""px;\n
                                background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba("""+color_rgba+"""));\n
                         }"""
        elif (num_box==3 and choice==True):
            # Boites 3 : personalisée
            styleSheet = """QFrame{\n
                                border-radius : """+str(L_WINDOW//28)+"""px;\n
                                background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba("""+color_rgba+"""));\n
                         }"""
    
        
        else : # Defaut
            # Boites formes : bleu ciel
            styleSheet = """QFrame{\n
                                border-radius : """+str(L_WINDOW//28)+"""px;\n
                                background-color : qconicalgradient(cx:0.5, cy:0.5, angle:90, stop:{STOP_1} rgba(255, 0, 127, 0), stop:{STOP_2} rgba(85, 170, 255, 255));\n
                         }"""
    
    
    
        # Valeur à fournir à la progress bar (25% -> 0.750)
        #Inversion des valeurs et nombre entre 0.000 et 1.000
        progress = (100 - value) / 100.0
 
        # Nouvelles valeurs
        stop_1 = str(progress-0.001)
        stop_2 = str(progress)
    
        # Nouvelles styleSheet avec les nouvelles valeurs, refresh la progress bar
        newStylesheet = styleSheet.replace("{STOP_1}", stop_1).replace("{STOP_2}", stop_2)
        # Application de la nouvelle styleSheet à la circularProgress
        if num_box == 1:
            self.circularProgress1.setStyleSheet(newStylesheet)
        elif num_box == 2:
            self.circularProgress2.setStyleSheet(newStylesheet)
        elif num_box == 3:
            self.circularProgress3.setStyleSheet(newStylesheet)

    
    def signalContinu(self, text, image):
        """Méthode associée au signal que l'on émet à période régulière.
        A chaque période, on refresh le pourcentage et on le remplie graphiquement
        
        Parameters
        ----------
        text : texte à afficher à période régulière dans la console

        """
    
        print(text)
        print(marche)
        # self.changeTestpourcentage()
        
          
        self.set_pourcentage([pourcentage_box[0], pourcentage_box[1], pourcentage_box[2]])
        
        self.label_video.setPixmap(QtGui.QPixmap.fromImage(image))
        
        config.current_slider = self.slider.value()
        # print(current_slider)

            
        
    def changeTestpourcentage(self):
        """Fonction de test pour changer le pourcentage des boîtes

        """
        global pourcentage_box, marche
                   
        if marche !=0 :
            pourcentage_box[0]+=5
            pourcentage_box[1]+=2
            pourcentage_box[2]+=1
           
                        

    def initServoPressed(self):
        """
        Retour des servomoteurs en position initiale, et pourcentages à 0%
        """    
        global servo_retour
        servo_retour = 1
        global pourcentage_box
        
        
        config.remplissage_color = {'ROUGE': 0, 'ORANGE': 0, 'JAUNE': 0, 'VERT_CLAIR': 0, 
                    'VERT_FONCE' : 0, 'BLEU_CLAIR': 0, 'BLEU_FONCE': 0,
                     'VIOLET': 0, "ROSE" : 0, "MARRON" : 0, "INDEFINI" : 0}  
        config.remplissage_shape = {'TRIANGLE': 0, 'CARRE': 0, 'RECTANGLE': 0,
                   'PENTAGONE': 0, 'HEXAGONE' : 0, 'ETOILE': 0, 'CERCLE': 0} 
        
        #Remplie le pourcentage initialiser à 0 sur les roues chromatiques de %
        pourcentage_box = [0, 0, 0]
        self.set_pourcentage(pourcentage_box)             
                
                

            
if __name__ == "__main__":
   
    app = QtWidgets.QApplication(sys.argv)
    if not app: # sinon on crée une instance de QApplication
        app = QtWidgets.QApplication(sys.argv) 
    
    MainWindow = QtWidgets.QMainWindow()
    ui = Ui_MainWindow()
    ui.setupUi(MainWindow)
    
    MainWindow.show()
    
    sys.exit(app.exec_())
   
    
   