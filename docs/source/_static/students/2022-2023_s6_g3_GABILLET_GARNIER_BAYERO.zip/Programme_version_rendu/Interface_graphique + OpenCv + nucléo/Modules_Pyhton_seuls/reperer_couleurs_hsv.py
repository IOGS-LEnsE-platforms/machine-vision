# -*- coding: utf-8 -*-
"""
Created on Wed Feb 15 19:31:31 2023

@author: Julien
"""



__authors__ = ("Julien Garnier")
__copyright__ = "SupOptique"
__date__ = "2023-05-10"
__version__= "2.0"


import cv2
import numpy as np


lower=np.array([5,95, 120])
upper=np.array([255,255,255])
color_infos=(0, 255, 255)
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)#Recup Webcam à 0, récup externe 1 

while True:
    ret, frame=cap.read()#retour et récup image
    image_hsv=cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)# changment de RGB à HSV
    height, width, ret = image_hsv.shape
    #Seuillage pour créer un masque selon couleur dans l'espace HSV
    #frame_threshold = cv.inRange(frame_HSV, (low_H, low_S, low_V), (high_H, high_S, high_V))
   
    cx = int(width/2)
    cy = int(height/2)
    
   
    masque=cv2.inRange(image_hsv, lower, upper)
    image_hsv=cv2.blur(image_hsv, (7,7))
    
    
    image2=cv2.bitwise_and(frame, frame, mask=masque)
    elements=cv2.findContours(masque, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    if len(elements) > 0:
        c=max(elements, key=cv2.contourArea)
        ((x,y), rayon)=cv2.minEnclosingCircle(c)
        # if rayon>30:
            # cv2.circle(image2, (int(x), int(y)), int(rayon), color_infos, 2)
            #cv2.circle(frame, (int(x), int(y)), 5, color_infos, 10)
            # cv2.line(frame, (int(x), int(y)), (int(x)+150, int(y)), color_infos, 2)
            # cv2.putText(frame, "Objet !!!", (int(x)+10, int(y)-10), cv2.FONT_HERSHEY_DUPLEX, 1, color_infos, 1, cv2.LINE_AA)

    #Pixel du centre, couleur, acquisition
    pixel_center = image_hsv[cy, cx]
    hue_value = pixel_center[0] # Teinte
    
    saturation = pixel_center[1] # Saturation
    
    value =pixel_center[2] # Luminosité
    
    color = "Indéfini"
    if value<30:
        color = "INDEFINI"
    elif (hue_value < 45 or hue_value > 160) and saturation<160 and value<120: #10, 120, 100
        color = "MARRON"
    elif (hue_value > 140 and hue_value < 177) and saturation<150 and value > 120:
        color = "ROSE"#174
            
    elif hue_value < 5 :#2 - 178
        color = "ROUGE"
    elif hue_value < 18:
        color = "ORANGE"#7
    elif hue_value < 35:
        color = "JAUNE"#21
    elif hue_value < 50:
        color = "VERT_CLAIR"#44
    elif hue_value < 90:
        color = "VERT_FONCE"#87
    elif hue_value < 104:
        color = "BLEU_CLAIR"
    elif hue_value < 118:
        color = "BLEU_FONCE"#105
    elif hue_value < 140:
        color = "VIOLET"#123-135
    elif hue_value < 180: # 177, 163, 234
        color = "ROUGE"
    else:
        color="ROUGE"
      
        
        
    print(pixel_center)
    pixel_center_bgr = frame[cy, cx]
    b, g, r = int(pixel_center_bgr[0]), int(pixel_center_bgr[1]), int(pixel_center_bgr[2])
    cv2.putText(frame, color, (10, 70), 0, 1.5, (b, g, r), 2)
    cv2.circle(frame, (cx, cy), 20, (25, 25, 25), 2)
    cv2.putText(frame, "Zone couleur", (cx-55, cy-50), cv2.FONT_HERSHEY_DUPLEX, 0.5, color_infos, 1, cv2.LINE_AA)


    cv2.imshow('Camera', frame)
    cv2.imshow('image2', image2)
    cv2.imshow('Mask', masque)
    if cv2.waitKey(1)==ord('q')\
    or cv2.getWindowProperty("Camera", cv2.WND_PROP_VISIBLE) <1:
        break
cap.release()
cv2.destroyAllWindows()


