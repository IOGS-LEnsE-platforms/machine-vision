# -*- coding: utf-8 -*-
"""
Created on Sat Mar 11 18:40:22 2023

@author: Julien
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Feb 16 18:08:38 2023

@author: Julien
"""

__authors__ = ("Julien Garnier")
__copyright__ = "SupOptique"
__date__ = "2023-05-10"
__version__= "2.3"


"Appuyer sur t pour lire l'image, ou screen le flux vidéo pour détecter la forme"

import cv2
# import numpy as np
# import time

#Taille d'acceptation de la forme en px²
SIZE_AREA_PX_MIN = 3 #300
SIZE_AREA_PX_MAX = 10000000 #8000
#Seuillage en binaire
#SEUIL=40

WIDTH = 640
HEIGHT = 480



def pick_shape(approx):
    """     
    pick_shape(ndarray approx) -> str
   
    Fonction permettant de renvoyer la figure détectée selon le nombre de coins
    acquis.
    
    Parameters 
    ----------
    approx : ndarray
        Toutes les coordonnées des coins de la figure récupérées avec OpenCv.
    
    Returns  
    -------
    shape : str 
        Figure détectée selon le nombre de coins dans la figure
    """
    shape = ""
    if len(approx) == 3:
        shape = "TRIANGLE"
    elif len(approx) == 4:
        x1, y1, w, h = cv2.boundingRect(approx)
        aspect_ratio = float(w) / float(h)
        if aspect_ratio >= 0.85 and aspect_ratio <= 1.15:
            shape = "CARRE"
        else:
            shape = "RECTANGLE"

    elif len(approx) == 5:
        shape = "PENTAGONE"
        
    elif len(approx) == 6:
        shape = "HEXAGONE"

    elif len(approx) == 12:
        shape = "ETOILE"

    else:
        shape = "CERCLE"

    print(f"forme : {shape}")

    return shape


def affichage_continu_traitement_formes(frame):
    """Fonction à activer pour afficher le flux continu en vidéo 
    pour observer le traitement sur l'image
    

    Parameters
    ----------
    frame : ndarray
        image acquise à flux régulier (vidéo)

    """
    
    # =====================================================================
    #         Rognage et seuillage video du convoyeur pour l'affichage
    # =====================================================================

    
    #Définition d'une zone de détection
    # y1 = 200
    # y2 = 400
    # x1 = 100
    # x2 = 600
    # img_convoyeur = frame[y1:y2, x1:x2]
    img_convoyeur = frame

    img_gray_conv = cv2.cvtColor(img_convoyeur, cv2.COLOR_BGR2GRAY)

    img_gray_conv = cv2.blur(img_gray_conv, (4, 4))

    # seuil = cv2.getTrackbarPos("seuil", "Seuillage")
    seuil = 70
    
    # Seuillage binaire tel que niveau_de_gris > 40 on met en blanc=255 les formes
    ret, thresh = cv2.threshold(
        img_gray_conv, seuil, 255, cv2.THRESH_BINARY)
    
    cv2.imshow("Acquisition", frame)
    cv2.imshow("Convoyeur", img_convoyeur)
    cv2.imshow("Seuillage", thresh)
    


def detection_formes(frame, remplissage):
    """     
    detection_formes(void) -> dict : remplissage
    
    Fonction permettant de détecter des formes dans une acquisition d'une image'
    
    Parameters 
    ----------
    frame : ndarray
        Acquisition ndarray de l'image issue du flux video.
        
    remplissage :  dict
        Dictionnaire initialisée auparavant à null qui compte le nombre de formes.
        Les formes sont comptées et associées à la clé "formes" : comptage.
    
    Returns  
    -------
    remplissage :  dict
        Dictionnaire actualisé de détection de formes : "formes" : comptage.
    """
    
    shape = ""
    
    #Définition d'une zone de détection
    # y1 = 200
    # y2 = 400
    # x1 = 100
    # x2 = 600
    # img_convoyeur = frame[y1:y2, x1:x2]
    img_convoyeur = frame
    
    img_gray_conv = cv2.cvtColor(img_convoyeur, cv2.COLOR_BGR2GRAY)
    
    img_gray_conv = cv2.blur(img_gray_conv, (4, 4))
    
  
    
    # seuil = cv2.getTrackbarPos("seuil", "Seuillage")
    seuil = 70
    
    # Seuillage binaire tel que niveau_de_gris > 40 on met en blanc=255 les formes
    ret, thresh = cv2.threshold(
        img_gray_conv, seuil, 255, cv2.THRESH_BINARY)
    
    
    # Détection de contours, en mode = cv2.RETR_EXTERNAL  (uniquement contour extérieur sans hiérarchie détecté)
    # et approximation simple
    contours, ret = cv2.findContours(
        thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    #Contour est un tuple qui contient toutes les figures et leur points détectés dans une liste

    # =====================================================================
    #         remplissage des formes
    # =====================================================================
    #compteur de figures

    #Parcours des figures
    for c in contours:

        #Tenir en compte que des formes de tailles importantes
        area = cv2.contourArea(c)
        if area > SIZE_AREA_PX_MIN and area < SIZE_AREA_PX_MAX:

            #approximation des polygones (curves, erreur epsilon, contour fermé), pour obtenir des formes fermées
            #Epsilon est très important pour la détection de la forme
            approx = cv2.approxPolyDP(c, 0.03*cv2.arcLength(c, True), True)

            #Dessin des contours (image, contours des formes, couleur, épaisseur trait)
            cv2.drawContours(img_convoyeur, [approx], 0, (255, 0, 0), 3)

            # #Zone verte, pour simplifier le centre de gravité lors du franchissment de la ligne
            (x, y, w, h) = cv2.boundingRect(c)
            cv2.rectangle(img_convoyeur, (x, y),
                          (x+w, y+h), (0, 255, 0), 1)
            x_grav = x+int(w/2)
            y_grav = y+int(h/2)

            #Affichage centre de gravité
            cv2.circle(img_convoyeur, (x_grav, y_grav), 3, (0, 0, 255), -1)



            #alors on détecte la forme
            shape = pick_shape(approx)
            remplissage[shape] += 1  # Compteur de la forme

       

            #Ou zone bleue
            #Position la plus à gauche des formes pour écriture de textes en concaténant
            x_txt = approx.ravel()[0]
            y_txt = approx.ravel()[1]-5

    # =====================================================================
    #             Association des formes aux contours à l'affichage
    # =====================================================================

            #Selon le nombre de coins, on associe la forme
            if len(approx) == 3:
                cv2.putText(img_convoyeur, "Triangle", (x_txt, y_txt),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            elif len(approx) == 4:
                x1, y1, w, h = cv2.boundingRect(approx)
                aspect_ratio = float(w) / float(h)
                if aspect_ratio >= 0.85 and aspect_ratio <= 1.15:
                    cv2.putText(img_convoyeur, "Carre", ((x_txt, y_txt)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
                else:
                    cv2.putText(img_convoyeur, "Rectangle", ((x_txt, y_txt)),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            elif len(approx) == 5:
                cv2.putText(img_convoyeur, "Pentagone", ((x_txt, y_txt)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            elif len(approx) == 6:
                cv2.putText(img_convoyeur, "Pentagone", ((x_txt, y_txt)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            elif len(approx) == 12:
                cv2.putText(img_convoyeur, "Etoile", ((x_txt, y_txt)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            else:
                cv2.putText(img_convoyeur, "Cercle", ((x_txt, y_txt)),
                            cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)


    return shape, remplissage



def empty(img):
    pass

if __name__ == "__main__":
    
    # ce qu'on reçoit au départ
    remplissage = {'TRIANGLE': 0, 'CARRE': 0, 'RECTANGLE': 0,
                 'PENTAGONE': 0, 'HEXAGONE' : 0, 'ETOILE': 0, 'CERCLE': 0} 
    # remplissage = {'PENTAGONE': 0, 'CARRE': 0, 'CERCLE': 0} 
    shape = 0
    
    # Lecture de l'image
    # Récuperer la Webcam à 0, récupérer externe 1
    video = cv2.VideoCapture(0, cv2.CAP_DSHOW)
      
    cv2.namedWindow("Seuillage")
    cv2.resizeWindow("Seuillage", 400, 300)
    cv2.createTrackbar("seuil", "Seuillage", 180, 255, empty)

   #FLux vidéo continu
    while True:
        ret, frame = video.read()  # retour et récup image
        # Conversion en niveau de gris (car formes à détecter sur fond noir sont simples à seuiller)

        affichage_continu_traitement_formes(frame)
        
        
        #Screenshot et traitement de l'image acquise en appuyant sur 't'
        if cv2.waitKey(20) == ord('t'):
            #Lecture image -> remplacer par la détection de la cellule TOR
            # shape, remplissage = detection_formes(frame, remplissage)
            image_test = cv2.imread("Pentagone.png")
            shape, remplissage = detection_formes(image_test, remplissage)
                


        if cv2.waitKey(20) == ord('q')\
                or cv2.getWindowProperty("Acquisition", cv2.WND_PROP_VISIBLE) < 1\
                or cv2.getWindowProperty("Seuillage", cv2.WND_PROP_VISIBLE) < 1\
                or cv2.getWindowProperty("Convoyeur", cv2.WND_PROP_VISIBLE) < 1:
            break
            
        print(f"forme : {shape} , nb rempli : {remplissage}")
    print(remplissage)
        
    video.release()
    cv2.destroyAllWindows()


