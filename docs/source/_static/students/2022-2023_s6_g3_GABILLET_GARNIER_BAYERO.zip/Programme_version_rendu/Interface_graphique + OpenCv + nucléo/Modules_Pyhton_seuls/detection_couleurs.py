# -*- coding: utf-8 -*-
"""
Created on Wed Feb 15 19:31:31 2023

@author: Julien
"""



__authors__ = ("Julien Garnier")
__copyright__ = "SupOptique"
__date__ = "2023-05-10"
__version__= "2.2"

"Appuyer sur t pour lire l'image, ou screen le flux vidéo pour détecter la couleur"


import cv2
import numpy as np


WIDTH = 640
HEIGHT = 480

lower=np.array([5,95, 120])
upper=np.array([255,255,255])
color_infos=(0, 255, 255)
cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)#Recup Webcam à 0, récup externe 1 

def pick_color(pixel_center):
    """ pick_color(ndarray) -> str
    
     Fonction permettant de renvoyer la couleur acquise selon le pixel centrale
     de données HSV (Hue Saturation Value)
     
    

    Parameters
    ----------
    pixel_center : ndarray
        
    Returns
    -------
    color : str
        couleur trouvée selon la teinte/saturation/luminosite du pixel central.

    """
   
    hue_value = pixel_center[0] # Teinte
    
    saturation = pixel_center[1] # Saturation
    
    value=pixel_center[2] # Luminosité
    
    color = "Indéfini"
    if value<30:
        color = "INDEFINI"
    elif (hue_value < 45 or hue_value > 160) and saturation<160 and value<120: #10, 120, 100
        color = "MARRON"
    elif (hue_value > 140 and hue_value < 177) and saturation<150 and value > 120:
        color = "ROSE"#174
            
    elif hue_value < 5 :#2 - 178
        color = "ROUGE"
    elif hue_value < 18:
        color = "ORANGE"#7
    elif hue_value < 35:
        color = "JAUNE"#21
    elif hue_value < 50:
        color = "VERT_CLAIR"#44
    elif hue_value < 90:
        color = "VERT_FONCE"#87
    elif hue_value < 104:
        color = "BLEU_CLAIR"
    elif hue_value < 118:
        color = "BLEU_FONCE"#105
    elif hue_value < 140:
        color = "VIOLET"#123-135
    elif hue_value < 180: # 177, 163, 234
        color = "ROUGE"
    else:
        color="ROUGE"
        
    return color

def affichage_continu_traitement_couleurs(frame):
    
    """Fonction à activer pour afficher le flux continu en vidéo 
    pour observer le traitement sur l'image
    

    Parameters
    ----------
    frame : ndarray
        image acquise à flux régulier (vidéo)

    """
    
    # =====================================================================
    #         Rognage et seuillage video du convoyeur pour l'affichage
    # =====================================================================

    
    #Définition d'une zone de détection
    # y1 = 200
    # y2 = 400
    # x1 = 100
    # x2 = 600
    # img_convoyeur = frame[y1:y2, x1:x2]
    img_convoyeur = frame

    image_hsv=cv2.cvtColor(img_convoyeur, cv2.COLOR_BGR2HSV)# changment de RGB à HSV
    height, width, ret = image_hsv.shape
    #Seuillage pour créer un masque selon couleur dans l'espace HSV
    #frame_threshold = cv.inRange(frame_HSV, (low_H, low_S, low_V), (high_H, high_S, high_V))
   
    masque=cv2.inRange(image_hsv, lower, upper)
    image_hsv=cv2.blur(image_hsv, (7,7))
    
    image2=cv2.bitwise_and(frame, frame, mask=masque)
    
    cv2.imshow('Acquisition', frame)
    cv2.imshow("Convoyeur", img_convoyeur)
    cv2.imshow('image2', image2)
    cv2.imshow('Mask', masque)



def detection_couleurs(frame, remplissage):
    """Fonction qui permet de détecter la couleur au centre de l'image
    

    Parameters
    ----------
    frame : ndarray
        DESCRIPTION.
    remplissage : dict
        Dictionnaire initialisée auparavant à null qui compte le nombre de couleurs.
        Les couleurs sont comptées et associées à la clé "color" : comptage.

    Returns
    -------
    color : str
        couleur trouvée
    remplissage : dict
        Actualisation du dictionnaire du comptage de couleurs.

    """
    
    #Définition d'une zone de détection
    # y1 = 200
    # y2 = 400
    # x1 = 100
    # x2 = 600
    # img_convoyeur = frame[y1:y2, x1:x2]
    img_convoyeur = frame

    image_hsv=cv2.cvtColor(img_convoyeur, cv2.COLOR_BGR2HSV)# changment de RGB à HSV
    height, width, ret = image_hsv.shape
    #Seuillage pour créer un masque selon couleur dans l'espace HSV
    #frame_threshold = cv.inRange(frame_HSV, (low_H, low_S, low_V), (high_H, high_S, high_V))
   
    
    
    masque=cv2.inRange(image_hsv, lower, upper)
    image_hsv=cv2.blur(image_hsv, (7,7))
    
    image2=cv2.bitwise_and(frame, frame, mask=masque)
    elements=cv2.findContours(masque, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)[-2]
    
    x=0
    y=0
    
    if len(elements) > 0:
        c=max(elements, key=cv2.contourArea)
        ((x,y), rayon)=cv2.minEnclosingCircle(c)
        if rayon>30:
            cv2.circle(image2, (int(x), int(y)), int(rayon), color_infos, 2)
            cv2.circle(frame, (int(x), int(y)), 5, color_infos, 10)
            cv2.line(frame, (int(x), int(y)), (int(x)+150, int(y)), color_infos, 2)
            cv2.putText(frame, "Objet !!!", (int(x)+10, int(y)-10), cv2.FONT_HERSHEY_DUPLEX, 1, color_infos, 1, cv2.LINE_AA)

    #Pixel du centre, couleur, acquisition
    pixel_center = image_hsv[int(y), int(x)]
    color = pick_color(pixel_center)
    remplissage[color] += 1  # Compteur de la forme

    
        
    # print(pixel_center)
    # pixel_center_bgr = frame[cy, cx]
    # b, g, r = int(pixel_center_bgr[0]), int(pixel_center_bgr[1]), int(pixel_center_bgr[2])
    # cv2.putText(frame, color, (10, 70), 0, 1.5, (b, g, r), 2)
    # cv2.circle(frame, (cx, cy), 20, (25, 25, 25), 2)
    # cv2.putText(frame, "Zone couleur", (cx-55, cy-50), cv2.FONT_HERSHEY_DUPLEX, 0.5, color_infos, 1, cv2.LINE_AA)

    return color, remplissage
   
    
if __name__ == "__main__":
    
    # ce qu'on reçoit au départ
    remplissage = {'ROUGE': 0, 'ORANGE': 0, 'JAUNE': 0, 'VERT_CLAIR': 0, 
                'VERT_FONCE' : 0, 'BLEU_CLAIR': 0, 'BLEU_FONCE': 0,
                 'VIOLET': 0, "ROSE" : 0, "MARRON" : 0, "INDEFINI" : 0} 
    # remplissage = {'ROUGE': 0, 'VERT': 0, 'BLEU': 0} 
    color = 0
    
    # Lecture de l'image
    # Récuperer la Webcam à 0, récupérer externe 1
    video = cv2.VideoCapture(0, cv2.CAP_DSHOW)
     
    #FLux vidéo continu
    while True:
        ret, frame=cap.read()#retour et récup image
        # Conversion en niveau de gris (car formes à détecter sur fond noir sont simples à seuiller)

        affichage_continu_traitement_couleurs(frame)
        
        #Screenshot et traitement de l'image acquise en appuyant sur 't'
        if cv2.waitKey(20) == ord('t'):
            #Lecture image -> remplacer par la détection de la cellule TOR
            color, remplissage = detection_couleurs(frame, remplissage)
            cv2.imshow('acquisition', frame)
            # image_test = cv2.imread("bleu.png")
            # color, remplissage = detection_couleurs(image_test, remplissage)
                


        if cv2.waitKey(1)==ord('q')\
        or cv2.getWindowProperty("Acquisition", cv2.WND_PROP_VISIBLE) <1:
            break

            
        print(f"couleur : {color} , nb rempli : {remplissage}")
    print(remplissage)
        
    video.release()
    cv2.destroyAllWindows()


