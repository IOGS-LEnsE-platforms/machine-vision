# -*- coding: utf-8 -*-
"""
Created on Mon Feb 27 16:44:13 2023

@author: clara.soncin
"""

import sys

from PyQt5.QtWidgets import QApplication, QDialog, QMainWindow, QPushButton, QCheckBox 
from PyQt5 import uic
from serial import Serial
import serial.tools.list_ports


class UI(QMainWindow): # charge la fenêtre principal de l'interface
    def __init__(self):
        super(UI,self).__init__()
        
        #load the ui file : charge le code de l'interface créée
        uic.loadUi("fenetre1.ui", self)
        
        #Define our Widgets : attribue un nom dans ce programme Python à l'action de chaque boutton
        self.tri_forme = self.findChild(QPushButton,"pushButton_2")
        self.tri_couleur = self.findChild(QPushButton,"pushButton_3")
        self.arret = self.findChild(QPushButton,"pushButton_4")
        self.init_connex = self.findChild(QPushButton, "pushButton")
        self.arret_connex = self.findChild(QPushButton, "pushButton_5")
        
        # Do something : attribue une fonction à une action réalisée sur un bouton 
        self.tri_forme.clicked.connect(self.clicker_forme)
        self.tri_couleur.clicked.connect(self.clicker_couleur)
        self.arret.clicked.connect(self.clicker_arret)
        self.init_connex.clicked.connect(self.clicker_init_connex)
        self.arret_connex.clicked.connect(self.clicker_arret_connex)
        
        # Show the App : permet l'affichage de l'application
        self.show()

    def clicker_forme(self): # fonction associée au bouton "Trier les formes"
        print("les formes fonctionnent")
        dialog = choix_formeDialog(self)
        dialog.exec()
        
    def clicker_couleur(self): # fonction associée au bouton "Trier les couleurs"
        print("les couleurs fonctionnent")
        
    def clicker_arret(self): # fonction associée au bouton "Arreter le tri"
        test_arret(self)
    
    def clicker_init_connex(self): # fonction azsociée au bouton "initialiser la connexion"
        ports = serial.tools.list_ports.comports()  #nom du port
            
            	# To obtain the list of the communication ports
        for port, desc, hwid in sorted(ports):
            print(port, desc)
            	# To select the port to use
        selectPort = input("Select a COM port : ") #l’utilisateur rentre le numéro du port à utiliser  
        print("Port Selected : COM{selectPort}")
            	# To open the serial communication at a specific baudrate
        serNuc = Serial('COM'+str(selectPort), 115200)  # Under Windows only, Dis sur quel port ça écrit
        appOk = 1 #idée : on fait une boucle et quand on envoie q, on en sort, sinon ça fonctionne h24
        while appOk:
            data_to_send = input("Char to send : ")
            if data_to_send == 'q' or data_to_send == 'Q':
                appOk = 0
            else:
                serNuc.write(bytes(data_to_send, "utf-8")) #écrit sur la carte le caractère reçu
            while serNuc.inWaiting() == 0:
                pass
            data_rec = serNuc.read(1)  # bytes, confirmation de l’envoie
            print(str(data_rec))
           	 
        serNuc.close() #on sort du port utilisé
    
    def clicker_arret_connex(self): # fonction associée au bouton "arreter la connexion"
        print("arret ok")
        
            
        
class choix_formeDialog(QDialog): # charge la fenêtre secondaire de l'interface associée au bouton "Trier les formes"
    def __init__(self, parent=None):
        super().__init__(parent)
        
        #load the ui file
        uic.loadUi("choix_formes.ui", self)
        
        #Define our Widgets : association des boutons à un nom sous Python
        self.carre = self.findChild(QCheckBox,"checkBox")
        self.rectangle = self.findChild(QCheckBox,"checkBox_2")
        self.triangle = self.findChild(QCheckBox,"checkBox_3")
        self.etoile = self.findChild(QCheckBox,"checkBox_3")
        self.cercle = self.findChild(QCheckBox,"checkBox_3")
        self.autre = self.findChild(QCheckBox,"checkBox_3")
        
        # Do something
        
        # Show the App
        self.show()


def test_arret(self): # fonction externe associée au bouton "arreter le tri" sert de test pour utiliser des fonctions externe 
    print("le test arret fonctionne")
#initialize the App
app = QApplication(sys.argv)
UIWindow = UI()
app.exec_()
